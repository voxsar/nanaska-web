--
-- PostgreSQL database dump
--

\restrict nCzFTSwLltur4Wr4dX1bfcRnpmgVGmpyWYJ1wtgjl3Gu4HQaTmAiRDlHNjyyka5

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_courses DROP CONSTRAINT IF EXISTS user_courses_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_courses DROP CONSTRAINT IF EXISTS user_courses_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_courses DROP CONSTRAINT IF EXISTS user_courses_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_payment_link_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_combination_id_fkey;
ALTER TABLE IF EXISTS ONLY public.enrollment_reminders DROP CONSTRAINT IF EXISTS enrollment_reminders_enrollment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_combination_items DROP CONSTRAINT IF EXISTS course_combination_items_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_combination_items DROP CONSTRAINT IF EXISTS course_combination_items_combination_id_fkey;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.user_courses_user_id_course_id_key;
DROP INDEX IF EXISTS public.site_settings_key_key;
DROP INDEX IF EXISTS public.payment_links_slug_key;
DROP INDEX IF EXISTS public.page_meta_page_path_key;
DROP INDEX IF EXISTS public.newsletter_signups_email_key;
DROP INDEX IF EXISTS public.enrollment_reminders_enrollment_id_reminder_number_key;
DROP INDEX IF EXISTS public.courses_slug_key;
DROP INDEX IF EXISTS public.course_combinations_slug_key;
DROP INDEX IF EXISTS public.course_combination_items_combination_id_course_id_key;
DROP INDEX IF EXISTS public.blog_posts_slug_key;
DROP INDEX IF EXISTS public.admin_users_email_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_courses DROP CONSTRAINT IF EXISTS user_courses_pkey;
ALTER TABLE IF EXISTS ONLY public.testimonials DROP CONSTRAINT IF EXISTS testimonials_pkey;
ALTER TABLE IF EXISTS ONLY public.site_settings DROP CONSTRAINT IF EXISTS site_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_links DROP CONSTRAINT IF EXISTS payment_links_pkey;
ALTER TABLE IF EXISTS ONLY public.page_meta DROP CONSTRAINT IF EXISTS page_meta_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.newsletter_signups DROP CONSTRAINT IF EXISTS newsletter_signups_pkey;
ALTER TABLE IF EXISTS ONLY public.lecturers DROP CONSTRAINT IF EXISTS lecturers_pkey;
ALTER TABLE IF EXISTS ONLY public.enrollment_submissions DROP CONSTRAINT IF EXISTS enrollment_submissions_pkey;
ALTER TABLE IF EXISTS ONLY public.enrollment_reminders DROP CONSTRAINT IF EXISTS enrollment_reminders_pkey;
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS courses_pkey;
ALTER TABLE IF EXISTS ONLY public.course_combinations DROP CONSTRAINT IF EXISTS course_combinations_pkey;
ALTER TABLE IF EXISTS ONLY public.course_combination_items DROP CONSTRAINT IF EXISTS course_combination_items_pkey;
ALTER TABLE IF EXISTS ONLY public.contact_submissions DROP CONSTRAINT IF EXISTS contact_submissions_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_posts DROP CONSTRAINT IF EXISTS blog_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.admin_users DROP CONSTRAINT IF EXISTS admin_users_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_courses;
DROP TABLE IF EXISTS public.testimonials;
DROP TABLE IF EXISTS public.site_settings;
DROP TABLE IF EXISTS public.payment_links;
DROP TABLE IF EXISTS public.page_meta;
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.newsletter_signups;
DROP TABLE IF EXISTS public.lecturers;
DROP TABLE IF EXISTS public.enrollment_submissions;
DROP TABLE IF EXISTS public.enrollment_reminders;
DROP TABLE IF EXISTS public.courses;
DROP TABLE IF EXISTS public.course_combinations;
DROP TABLE IF EXISTS public.course_combination_items;
DROP TABLE IF EXISTS public.contact_submissions;
DROP TABLE IF EXISTS public.blog_posts;
DROP TABLE IF EXISTS public.admin_users;
DROP TYPE IF EXISTS public."OrderStatus";
DROP TYPE IF EXISTS public."AdminRole";
--
-- Name: AdminRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AdminRole" AS ENUM (
    'admin',
    'superadmin'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED',
    'REFUNDED',
    'ARCHIVED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    role public."AdminRole" DEFAULT 'admin'::public."AdminRole" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_posts (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    cover_url text,
    content text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    author_id text,
    meta_title text,
    meta_desc text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: contact_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_submissions (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    subject text,
    message text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: course_combination_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.course_combination_items (
    id text NOT NULL,
    combination_id text NOT NULL,
    course_id text NOT NULL
);


--
-- Name: course_combinations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.course_combinations (
    id text NOT NULL,
    level text NOT NULL,
    price integer NOT NULL,
    price_gbp integer DEFAULT 0 NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    slug text
);


--
-- Name: courses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courses (
    id text NOT NULL,
    name text NOT NULL,
    price integer NOT NULL,
    level text NOT NULL,
    slug text NOT NULL,
    description text,
    highlights text[],
    icon text,
    lecturer_name text,
    outcomes text[],
    subtitle text,
    syllabus jsonb DEFAULT '[]'::jsonb NOT NULL,
    duration text,
    "lecturerIds" text[],
    price_gbp integer DEFAULT 0 NOT NULL
);


--
-- Name: enrollment_reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrollment_reminders (
    id text NOT NULL,
    enrollment_id text NOT NULL,
    reminder_number integer NOT NULL,
    sent_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: enrollment_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrollment_submissions (
    id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    phone text,
    whatsapp text,
    cima_id text,
    cima_stage text,
    dob text,
    gender text,
    country text,
    city text,
    postcode text,
    notes text,
    cart_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    currency text DEFAULT 'GBP'::text NOT NULL,
    amount integer DEFAULT 0 NOT NULL,
    order_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: lecturers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lecturers (
    id text NOT NULL,
    name text NOT NULL,
    title text NOT NULL,
    credentials text[],
    bio text NOT NULL,
    bio2 text,
    image_url text,
    stats jsonb DEFAULT '[]'::jsonb NOT NULL,
    specialties text[],
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: newsletter_signups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.newsletter_signups (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id text NOT NULL,
    user_id text,
    combination_id text,
    amount integer NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    ipg_merchant_ref text,
    ipg_ref text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    guest_email text,
    guest_name text,
    guest_phone text,
    currency text DEFAULT 'LKR'::text NOT NULL,
    frontend_origin text,
    archived_at timestamp(3) without time zone,
    payment_link_id text
);


--
-- Name: page_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_meta (
    id text NOT NULL,
    page_path text NOT NULL,
    page_title text NOT NULL,
    meta_title text,
    meta_desc text,
    meta_keywords text,
    og_title text,
    og_desc text,
    og_image text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: payment_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_links (
    id text NOT NULL,
    slug text NOT NULL,
    label text NOT NULL,
    student_name text,
    student_email text,
    amount integer NOT NULL,
    currency text NOT NULL,
    description text,
    password_hash text,
    expires_at timestamp(3) without time zone,
    expire_on_payment boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_paid boolean DEFAULT false NOT NULL,
    paid_at timestamp(3) without time zone,
    created_by_admin_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    label text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id text NOT NULL,
    student_name text NOT NULL,
    country text NOT NULL,
    flag text NOT NULL,
    tag text NOT NULL,
    exam text NOT NULL,
    period text NOT NULL,
    year integer NOT NULL,
    marks integer,
    image_url text,
    quote text NOT NULL,
    video_url text,
    badge text,
    is_prize_winner boolean DEFAULT false NOT NULL,
    published boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: user_courses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_courses (
    id text NOT NULL,
    user_id text NOT NULL,
    course_id text NOT NULL,
    order_id text NOT NULL,
    granted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_users (id, email, password_hash, name, role, created_at, updated_at) FROM stdin;
5fb53fd8-59a7-4429-a655-d7c12be48be9	miyuru@theredsun.org	$2b$12$5SBmL79ii.fs48A2d8RXxOeo/3RfAPDvFnZTKXOvuTULgIUXKcoZq	Miyuru	superadmin	2026-03-20 07:06:16.226	2026-03-21 09:42:23.669
4d9672e4-6819-47cd-8d24-1e24d258e8ae	miyuru@nanaska.com	$2b$12$moCu1QndQXxaXN5sID04zumVJS5WUaG5Go8lsYaeKqPZdwFsQFEba	Miyuru	superadmin	2026-03-26 11:37:42.292	2026-03-27 14:35:43.104
948881ac-ce8b-4436-ad98-4ebfa0140572	info@nanaska.com	$2b$12$eUJbTiXaifThkSCSoS61ceQiq1MdOv3P68L7QIOs4TCGPvZcV35La	Nanaska Admin	admin	2026-03-20 07:04:29.956	2026-03-27 14:35:43.388
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_posts (id, title, slug, cover_url, content, published, author_id, meta_title, meta_desc, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contact_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_submissions (id, name, email, phone, subject, message, created_at) FROM stdin;
15c7d9c6-d12e-4cd4-bade-8dae6ed4928d	Autumn Cabrera	lymefivub@mailinator.com	+1 (318) 524-1462	Fees & Payment	Error autem et paria	2026-03-20 18:37:51.18
ecdab8be-3e5b-4b6e-b4b8-46cc39f8fb2d	Alma Mayer	zexatope@mailinator.com	+1 (307) 872-7636	Exam Preparation	Deleniti modi accusa	2026-03-24 18:20:38.691
bc607cf2-74f8-433d-93aa-90f8ee59b11c	ZPBqIYlXBbbHRmmVXeYodB	xav.o.r.i.f.elo.j.a.75@gmail.com	9462988333	General Enquiry	UYaRtieoMccmxgaECPpe	2026-03-26 01:52:41.225
8992776e-c717-4445-8a34-484fdfa51a2e	Alyssa Stone	alyssa@turbojot.com	2158218810	General Enquiry	Hi! My name is Alyssa and I’d love to invite you to try TurboJot. I actually founded the company. It’s built to automate contact form submissions at scale. Simply upload a list of URLs and TurboJot automatically finds and submits contact forms on those sites. It beats cold email and paid ads on ROI and costs just $0.10 per submission. Powered by a rotating IP network, stealth browser, AI captcha solving, and human-like browsing behavior. You can sign up for free and give it a try here. I’d really appreciate the support! https://www.turbojot.com/	2026-03-26 23:16:19.822
c8cc3f35-e11c-45d1-9080-39df8f0eebeb	Akalanka Ranasinghe	akalanka@nanaska.com	+94775844677	Course Information	saadasd	2026-03-27 09:36:37.064
d0987d9a-6620-403f-a892-44d3c362f2b6	HIRUNI RODRIGO	hirunirodrigo58@gmail.com	+94 743387331	Course Information	DETAILS ON CIMA FLP PROGRAM - NEXT INTAKE/FEE STRUCTURE/DURATION/ONLINE OR PHYSICAL	2026-03-29 08:46:16.243
\.


--
-- Data for Name: course_combination_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.course_combination_items (id, combination_id, course_id) FROM stdin;
41dfa111-3473-4cf0-a544-1d467ddcb734	cert_ba1	BA1
c639b737-07f8-4895-97a5-dd8c80ff551a	cert_ba2	BA2
1c8bc5e7-f3e6-4c7a-a303-c1ac218b12c8	cert_ba3	BA3
e06bc198-9df9-4764-8a1d-03d908f6e8ef	cert_ba4	BA4
3fd421b8-4f77-47c7-a9f9-7ca179b0587c	cert_ba1_ba2	BA1
af6d687e-7c38-452b-9b2a-750a624a5546	cert_ba1_ba2	BA2
11899177-5ebc-446b-bbad-50a4c8205fc2	cert_ba1_ba3	BA1
227a07f8-f67f-4f29-9528-4a5dc91fdbd8	cert_ba1_ba3	BA3
4ce65df6-9f1a-4084-aac2-a69d586dce6c	cert_ba1_ba4	BA1
ad92d225-b1d9-4c4b-9a70-4bd7fa9292f7	cert_ba1_ba4	BA4
c03b3a44-0126-4a56-82a6-0ede43e28c90	cert_ba2_ba3	BA2
69a2af35-75a4-483c-8bc9-1929128869f8	cert_ba2_ba3	BA3
b281cea1-a9ec-422e-a94c-8804a865d145	cert_ba2_ba4	BA2
a132ce35-d994-4aba-9477-b0cabf25ea2c	cert_ba2_ba4	BA4
018608a6-d19b-46f2-adef-514a0799b842	cert_ba3_ba4	BA3
e7943974-ca28-4d0a-9320-998bdd043943	cert_ba3_ba4	BA4
25e2cbf1-be09-40a4-9f4d-03e12a3d7ecf	op_e1	E1
063a8dc4-2078-47e8-a814-a11f1d379875	op_p1	P1
d986c4ab-416c-405d-9e50-6b18301ae0ff	op_f1	F1
eb018902-9a8d-42fa-be0d-fb2cbb9598ce	op_e1_p1	E1
26680ac2-e2f4-4f51-938a-604a32543575	op_e1_p1	P1
3eda9526-70c6-4393-93ae-76b97ba8eaae	op_e1_f1	E1
7cc7724e-8916-4bcc-9dd1-edd6480d43c3	op_e1_f1	F1
87f49050-34d6-432f-9639-133745d5743b	mg_p2	P2
614ec3af-d5ee-443c-ba0f-71abe967fef3	mg_f2	F2
6323f1e0-4770-4c88-90e1-ab018b96590f	mg_mcs	MCS
9bf0c837-3cf7-4b7e-aee4-90712e333c74	st_e3	E3
0473f629-42fb-412b-a2a8-26ff5b1506ea	st_p3	P3
6b66f364-d361-487b-8ce7-4dd5502f84c6	st_f3	F3
f90f38d8-6967-409c-9558-d32467355493	st_scs	SCS
32aa4565-9a50-466c-9421-055281f2cdb5	st_e3_p3	E3
dd5073be-f5fd-4b0f-89c5-04d77995ddac	st_e3_p3	P3
c8517c7f-a386-4bbb-92d6-d38016843d4c	cert_test	Test
3375be63-4f29-437b-998a-4365b3047b06	cert_ba1_ba2_ba3	BA1
f120669f-0d2a-4590-8ee4-c3da8ba275b4	cert_ba1_ba2_ba3	BA2
6ad279c6-6cf4-4d78-b230-c8070dca8529	cert_ba1_ba2_ba3	BA3
b989cf4d-fdac-4dda-8885-95f523953640	cert_ba1_ba2_ba4	BA1
30295372-7371-496f-ae7e-b2a45a384a0e	cert_ba1_ba2_ba4	BA2
2ed010c1-4b83-4ae0-89be-e9446b83d48c	cert_ba1_ba2_ba4	BA4
1f576f23-d288-4042-9e37-17ac52a1b5bd	cert_ba1_ba3_ba4	BA1
4ed30451-1b8c-4702-aee6-7495a1dcde54	cert_ba1_ba3_ba4	BA3
95aab13c-87bc-4475-9434-be340f3199a6	cert_ba1_ba3_ba4	BA4
de48a21b-e815-4e35-81f0-b666a79cb8e9	cert_ba2_ba3_ba4	BA2
809bf93c-f6fb-443f-987c-da7fc1561b4f	cert_ba2_ba3_ba4	BA3
7084baa8-2993-40ec-8c3d-72a0d7f2528c	cert_ba2_ba3_ba4	BA4
18f0d1ce-6194-4f25-8ed3-a75fdd32c10d	cert_ba1_ba2_ba3_ba4	BA1
a2f1bf86-b085-4581-910b-ce4ae8ae3897	cert_ba1_ba2_ba3_ba4	BA2
ea1485b2-d6a8-4c3e-98a6-de1969515dd8	cert_ba1_ba2_ba3_ba4	BA3
5832ba57-92e2-45cc-ae34-a768a1aa0017	cert_ba1_ba2_ba3_ba4	BA4
4e0b2ef3-8bee-4654-a44d-292eed0a84f2	op_f1_p1	F1
c2bacf9e-9ade-483d-9fe0-6c39588cd5fd	op_f1_p1	P1
5f67acab-81c1-4def-8f71-66ddbd3ee9c6	op_e1_f1_p1	E1
445ee210-b33e-45c2-a839-79be26c76d03	op_e1_f1_p1	F1
a0792d0d-c728-4260-83f5-726b248aef9e	op_e1_f1_p1	P1
dbdf8b3c-ae7e-4077-8fa1-5486e5929758	op_ocs	OCS
127bff85-1108-4718-bc6e-9c43c6e4d853	op_e1_ocs	E1
ef05cbc1-99f6-4540-83a8-a3844be55ff7	op_e1_ocs	OCS
aa05dd9d-6790-451b-8742-464424d1701d	op_ocs_p1	OCS
e1498005-2398-4c73-9c17-c98f8cfa9665	op_ocs_p1	P1
4f337199-4a9b-4527-b598-ea80a56bd545	op_e1_ocs_p1	E1
6679e7e3-7758-439f-b8f2-5b31118f4833	op_e1_ocs_p1	OCS
5834663d-13aa-409f-b3f2-97915e01acd2	op_e1_ocs_p1	P1
81107e45-dd4a-473b-8bc2-f86508bcfc0b	op_f1_ocs	F1
ee56599a-d9cd-4f7f-9966-37cfce2a0b44	op_f1_ocs	OCS
dc8762cf-9546-490c-ac9d-6c38030856e3	op_e1_f1_ocs	E1
921fed36-6c37-41e9-8fb9-9cd5e70d223b	op_e1_f1_ocs	F1
bebd7ef0-e1e5-40e5-890e-8db689ed6589	op_e1_f1_ocs	OCS
05bda97d-a463-40d2-bd59-b3cdad19e33b	op_f1_ocs_p1	F1
fe71a209-b739-4e21-a8b7-4ba460895709	op_f1_ocs_p1	OCS
f834827f-ca0a-40f9-9cc6-5ea95e41ffa3	op_f1_ocs_p1	P1
73998560-a3e8-4f55-a3d9-ae8cd26b6217	op_e1_f1_ocs_p1	E1
ad1e380f-f41e-4a60-9f13-38079afc9d16	op_e1_f1_ocs_p1	F1
4729eb66-3864-4083-a0e5-2b56710d4784	op_e1_f1_ocs_p1	OCS
80e98250-3724-494a-b4ba-a4812dd4d87d	op_e1_f1_ocs_p1	P1
38cc3b8e-4940-4a07-b319-95bd1d4337b8	mg_e2	E2
7082621e-404a-4fc5-8c04-beea93fecaf1	mg_e2_p2	E2
17f20edf-f3d3-4c8e-98c2-0846098da038	mg_e2_p2	P2
baa3907e-1132-4076-820b-a4f2389754e1	mg_e2_f2	E2
6a9256fd-ebc4-41e1-b2b5-78f6ae252673	mg_e2_f2	F2
cec216fd-e948-4af8-a059-b0909cf76cbb	mg_f2_p2	F2
f766f766-57d3-4464-9724-3cc2f2f617fc	mg_f2_p2	P2
fe1dc77c-4653-4680-bba9-d6598d5d18a8	mg_e2_f2_p2	E2
714f64bc-fad4-4992-9cbc-7b83c2731321	mg_e2_f2_p2	F2
354dfb9f-b33b-4930-9b3c-73f485e178a8	mg_e2_f2_p2	P2
ff69b381-cdf7-4956-8924-fce5f12640ed	mg_e2_mcs	E2
a6755a51-f75d-4b47-8c99-a1af1cd45af8	mg_e2_mcs	MCS
8148159c-f3fc-4788-b146-2bc502086ffc	mg_mcs_p2	MCS
2345c32c-7887-430c-8b22-72d4ee7bcfbc	mg_mcs_p2	P2
9f785d40-4557-4461-90e1-d5bb80145e78	mg_e2_mcs_p2	E2
1875b731-ae36-4c94-a2e2-b746d9b5721e	mg_e2_mcs_p2	MCS
9923e00a-b1bd-478b-b24a-db283e0d2e9c	mg_e2_mcs_p2	P2
bcc060d6-65d9-4a25-b539-156696146418	mg_f2_mcs	F2
0aaada8e-0988-4f80-8d11-d20aa56376de	mg_f2_mcs	MCS
e23bf313-f09b-4c7c-8ab8-5954e94705fc	mg_e2_f2_mcs	E2
210a1cac-bfde-478b-8afc-b6f90ee2f2e7	mg_e2_f2_mcs	F2
6945ca6d-2ebf-4fc5-846d-076c5bdd0db7	mg_e2_f2_mcs	MCS
69df9edd-8848-4a58-b74e-d797e203f92f	mg_f2_mcs_p2	F2
1ec5c807-9c4f-43d3-b07e-ed28731bd79d	mg_f2_mcs_p2	MCS
4000918b-aea6-4e25-9136-e4e63bc402e0	mg_f2_mcs_p2	P2
55f56fa3-061f-4823-a41b-ce9a04806e26	mg_e2_f2_mcs_p2	E2
d43fca55-84cc-490b-994b-c1eeac75a5d6	mg_e2_f2_mcs_p2	F2
7525b2af-6e39-4c6d-ab38-62476bcd9760	mg_e2_f2_mcs_p2	MCS
e8eadc58-3fa3-42b2-89c3-36e29772b736	mg_e2_f2_mcs_p2	P2
1c158df1-629d-46a6-a865-4cade492e6f5	st_e3_f3	E3
b5aad463-f10b-4d31-b447-ea17f16c87fa	st_e3_f3	F3
d10e0bc2-674c-40c7-8631-2aa69c79edfd	st_f3_p3	F3
24e9f176-33c1-437f-b608-48df744d163f	st_f3_p3	P3
b93b34f2-2b2a-4897-92e8-2199d34a0078	st_e3_f3_p3	E3
fa37fd05-31ee-45ba-83a3-db8abdc48f84	st_e3_f3_p3	F3
c7b46e52-567e-41a1-8163-e02e29aee705	st_e3_f3_p3	P3
33b87a4d-1f3d-4986-a1e1-33b0b9e105b6	st_e3_scs	E3
d3f6809b-efe3-4075-ba5c-ef501566743e	st_e3_scs	SCS
d8871378-c752-434c-98b1-469c5b27ceb0	st_p3_scs	P3
1aa0118a-9bb3-4084-af0d-e4721287e111	st_p3_scs	SCS
4ebbfd42-5665-47d6-8cb7-f4d1f079ec84	st_e3_p3_scs	E3
1a68f9fa-89c8-4c23-a47f-59228cf22ff2	st_e3_p3_scs	P3
f6d82e44-999e-4060-a71d-cb526644f546	st_e3_p3_scs	SCS
6c210386-79a0-4c1d-828b-c1e17723dbb1	st_f3_scs	F3
2366d7cf-e5e7-437b-a56e-03e9078ccc8f	st_f3_scs	SCS
78374813-5fd8-4b8a-ab4c-82605aef8f62	st_e3_f3_scs	E3
6913e83c-7822-4287-943b-c4789a9e6189	st_e3_f3_scs	F3
42601b1c-6290-41ef-92e4-57b0b2913812	st_e3_f3_scs	SCS
d6e65212-3d7a-4266-a3e7-f4856dfcaeac	st_f3_p3_scs	F3
6d725123-3292-43bc-94ba-e66fdb65476e	st_f3_p3_scs	P3
f9aeb870-7f50-4370-ad19-ac76f5bb0d53	st_f3_p3_scs	SCS
e860069d-39f7-4ebc-8d96-7a3cb3e948f3	st_e3_f3_p3_scs	E3
7199594c-3eba-4754-bb19-9aa33b80961e	st_e3_f3_p3_scs	F3
86b1ab87-f450-4744-8f02-733f42de70fc	st_e3_f3_p3_scs	P3
043e25c0-4c08-4c87-af53-60ab5dc22b28	st_e3_f3_p3_scs	SCS
947b92da-4c75-4f18-8e04-b32b20b95b7b	mix_e1_e2	E1
f041c7a4-200c-4feb-8f6b-f1a3323023ae	mix_e1_e2	E2
3ac6f189-1cc5-44ce-a87c-483ad91f0517	mix_mcs_scs	MCS
bf41e3ac-dac0-4749-91d5-c20cf04b0f2a	mix_mcs_scs	SCS
d7a0f709-4305-40bc-ae57-0fb6c3f5fdd2	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	E1
82a47452-838d-4121-9359-8d7ffefbdd23	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	E2
08a5a369-5e8e-4810-9c2d-a4f98053f230	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	F1
424ca09b-3e78-4b8f-9742-9fc69e4a084c	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	F2
a0e17f42-8027-4927-84ad-cb06725bc6f3	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	MCS
2b553799-62d8-496b-9d4f-ccb1f3823b4c	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	OCS
5258689b-ac94-4f0d-8818-802ab36481be	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	P1
74f25e6f-ac00-48f6-a2ef-8221f910c157	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	P2
11c10452-0f1f-41c8-b34a-935d426c99d0	op_full	P1
8da84657-c05f-4c4a-ba64-08414a5fc21b	op_full	E1
8d60087f-97d8-46fb-b7da-ae6384dc007a	op_full	F1
56186808-defe-43cb-87ef-5a8546cb00a7	op_full	OCS
f47c8847-e523-4461-9f37-b9c627f0df85	mg_full	E2
2e6ff9a5-1426-428a-9fce-1f504b35de18	mg_full	P2
2cb1a199-111d-4844-9046-5a2102d33749	mg_full	F2
1dfeee42-4fe4-4a90-af2a-45f024f20fee	mg_full	MCS
76d51cdf-c282-4a0d-8b45-cd9bad351ffd	st_full	E3
5ec4c820-fd84-43ef-9246-0174e5e82b54	st_full	P3
104142de-7889-4d2f-923e-3255c15d6f37	st_full	F3
3bc189a9-bd49-4e32-b6d4-15c1eb43a863	st_full	SCS
0c446b8d-6cde-4dc9-b309-51c62a140d5a	cert_full	BA1
40c7111b-b675-475e-aa49-64d0eff21296	cert_full	BA2
ccdb5f13-008e-4588-bc99-438f5fb530bb	cert_full	BA3
851fd012-2ade-4d11-90a2-2d3671e5d63b	cert_full	BA4
\.


--
-- Data for Name: course_combinations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.course_combinations (id, level, price, price_gbp, name, slug) FROM stdin;
cert_test	certificate	1000	10		\N
st_full	strategic	105750	600	CIMA Strategic Level	cima-strategic-level
cert_full	certificate	55000	360	CIMA Certificate Level	cima-certificate-level
mg_e2	management	25000	200		\N
mg_p2	management	25000	200		\N
mg_e2_p2	management	50000	350		\N
mg_f2	management	25000	200		\N
mg_e2_f2	management	50000	350		\N
mg_f2_p2	management	70000	0		\N
mg_e2_f2_p2	management	75000	525		\N
mg_mcs	management	27675	499		\N
mg_e2_mcs	management	52675	674		\N
mg_mcs_p2	management	52675	674		\N
mg_e2_mcs_p2	management	77675	849		\N
mg_f2_mcs	management	52675	674		\N
mg_e2_f2_mcs	management	77675	849		\N
mg_f2_mcs_p2	management	77675	849		\N
mg_e2_f2_mcs_p2	management	102675	1024		\N
st_e3	strategic	25000	200		\N
st_p3	strategic	25000	200		\N
st_e3_p3	strategic	80000	0		\N
st_f3	strategic	25000	200		\N
st_e3_f3	strategic	50000	350		\N
cert_ba1	certificate	16000	105		\N
cert_ba2	certificate	16000	105		\N
cert_ba1_ba2	certificate	32000	210		\N
cert_ba3	certificate	16000	105		\N
cert_ba1_ba3	certificate	32000	210		\N
cert_ba2_ba3	certificate	32000	210		\N
cert_ba1_ba2_ba3	certificate	48000	315		\N
cert_ba4	certificate	16000	105		\N
cert_ba1_ba4	certificate	32000	210		\N
cert_ba2_ba4	certificate	32000	210		\N
cert_ba1_ba2_ba4	certificate	48000	315		\N
cert_ba3_ba4	certificate	32000	210		\N
cert_ba1_ba3_ba4	certificate	48000	315		\N
cert_ba2_ba3_ba4	certificate	48000	315		\N
cert_ba1_ba2_ba3_ba4	certificate	64000	420		\N
st_f3_p3	strategic	50000	350		\N
st_e3_f3_p3	strategic	75000	525		\N
st_scs	strategic	30750	599		\N
st_e3_scs	strategic	55750	774		\N
st_p3_scs	strategic	55750	774		\N
st_e3_p3_scs	strategic	80750	949		\N
st_f3_scs	strategic	55750	774		\N
op_e1	operational	25000	200		\N
op_p1	operational	25000	200		\N
op_e1_p1	operational	58000	0		\N
op_f1	operational	25000	200		\N
op_e1_f1	operational	58000	0		\N
op_f1_p1	operational	58000	0		\N
op_e1_f1_p1	operational	75000	525		\N
op_ocs	operational	26650	399		\N
op_e1_ocs	operational	51650	574		\N
op_ocs_p1	operational	51650	574		\N
op_e1_ocs_p1	operational	76650	749		\N
op_f1_ocs	operational	51650	574		\N
op_e1_f1_ocs	operational	76650	749		\N
op_f1_ocs_p1	operational	76650	749		\N
op_e1_f1_ocs_p1	operational	101650	924		\N
st_e3_f3_scs	strategic	80750	949		\N
st_f3_p3_scs	strategic	80750	949		\N
st_e3_f3_p3_scs	strategic	105750	1124		\N
mix_e1_e2	mixed	50000	350	Managing Finance in a Digital World + Managing Performance	\N
mix_mcs_scs	mixed	58425	1098	Management Case Study + Strategic Case Study	\N
mix_e1_e2_f1_f2_mcs_ocs_p1_p2	mixed	204325	1948	Management Case Study + Advanced Financial Reporting + Advanced Management Accounting + Operational Case Study + Management Accounting + Managing Finance in a Digital World + Managing Performance + Financial Reporting	\N
op_full	operational	75000	600	CIMA Operational Level	cima-operational-level
mg_full	management	77775	600	CIMA Management Level	cima-management-level
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courses (id, name, price, level, slug, description, highlights, icon, lecturer_name, outcomes, subtitle, syllabus, duration, "lecturerIds", price_gbp) FROM stdin;
MCS	Management Case Study	27675	management	management-case-study	The Management Case Study (MCS) is a three-hour integrated exam set within a realistic management-level business scenario. It tests the application of E2, P2 and F2 knowledge with particular emphasis on financial analysis, management control and strategic decision support.	{"Integration of E2, P2 and F2 knowledge","Realistic management-level business scenario","Strategic financial analysis and decision-making","Management control and performance measurement","Stakeholder communication and professional judgement","Expert case study coaching by Channa Gunawardana"}	🏢		{"Integrate E2, P2 and F2 knowledge within a management-level business context.","Evaluate complex management accounting issues and recommend solutions.","Prepare clear, professional reports and briefings for senior management audiences.","Apply change management and project management concepts to case scenario situations.","Manage exam time effectively and produce high-quality responses across all tasks."}	Integrated assessment combining E2, P2 and F2	[{"desc": "Thorough analysis of the pre-seen material including financials, industry context and strategy.", "topic": "Pre-Seen Mastery"}, {"desc": "Using P2 techniques in the MCS scenario for performance analysis and decision support.", "topic": "Management Accounting Application"}, {"desc": "Applying F2 standards and analysis within management reporting contexts.", "topic": "Financial Reporting Application"}, {"desc": "Using E2 frameworks for project management, stakeholder and change issues in the scenario.", "topic": "Managing Performance in Context"}, {"desc": "Full mock exams in Nanaska's exam engine, time management and marking review sessions.", "topic": "Exam Strategy & Mock Practice"}]	7 - 8 Weeks	{221aece0-07cd-470f-beba-3014d6a8cb32}	499
F2	Advanced Financial Reporting	25000	management	f2-advanced-financial-reporting	F2 advances financial reporting into complex territory — covering complex group structures, financial instruments, share-based payments, impairment, and a critical evaluation of financial reporting standards.	{"Complex group consolidations (associates, JVs)","Financial instruments — IFRS 9 in depth","Share-based payments (IFRS 2)","Impairment of assets (IAS 36)","Earnings per share (IAS 33)","Evaluation and critique of IFRS standards"}	📰		{"Prepare consolidated financial statements including associates and joint ventures.","Apply IFRS 9 to classify, measure and impair financial instruments.","Account for share-based payments and complex provisions.","Critically evaluate financial reporting standards and their application.","Analyse and interpret complex group financial statements."}	Complex IFRS, group accounts and financial analysis	[{"desc": "Consolidation of associates (IAS 28), joint ventures and complex subsidiary structures.", "topic": "Complex Group Accounts"}, {"desc": "IFRS 9 — classification, measurement, impairment and hedge accounting.", "topic": "Financial Instruments"}, {"desc": "IFRS 2 (share-based payment), IAS 36 (impairment), IAS 33 (EPS), IFRS 17 (insurance).", "topic": "Advanced IFRS Standards"}, {"desc": "Foreign exchange, hyperinflation, segment reporting and discontinuing operations.", "topic": "Reporting in Specialised Situations"}, {"desc": "Limitations of IFRS, debates on fair value, and current developments in financial reporting.", "topic": "Critical Evaluation"}]	4 Months	{91e313c1-99f7-41ee-9890-85158ed60f48}	175
P2	Advanced Management Accounting	25000	management	p2-advanced-management-accounting	P2 extends management accounting into advanced territory — covering advanced variance analysis, decision theory under uncertainty, capital investment appraisal, and strategic performance measurement systems.	{"Advanced variance analysis — planning vs operational variances","Decision-making under uncertainty (maximin, maximax, minimax regret)","Risk and uncertainty analysis","Capital investment appraisal (NPV, IRR, ARR)","Strategy and performance measurement","Divisional performance — ROI, RI and EVA"}	📐		{"Calculate and interpret advanced variance analysis including planning variances.","Apply decision theory techniques to problems involving risk and uncertainty.","Evaluate capital investment proposals using discounted cash flow methods.","Assess divisional performance using ROI, RI and EVA.","Design and critique strategic management control and performance measurement systems."}	Advanced planning, control and decision-making techniques	[{"desc": "Planning and operational variances, mix and yield variances for materials and sales.", "topic": "Advanced Variance Analysis"}, {"desc": "Expected values, sensitivity analysis, decision trees and scenario analysis.", "topic": "Uncertainty & Decision Theory"}, {"desc": "NPV, IRR, payback, ARR — selecting and evaluating capital investment projects.", "topic": "Long-run Decisions"}, {"desc": "ROI, residual income, Economic Value Added (EVA) and transfer pricing.", "topic": "Divisional Performance"}, {"desc": "Strategic performance frameworks, management control systems and risk.", "topic": "Strategy & Control"}]	4 Months	{def01bf9-8fb4-44b0-8b91-8a9c0f7f628e}	175
P3	Risk Management	25000	strategic	p3-risk-management	P3 equips students with the tools and frameworks to identify, assess, quantify and manage risks facing complex organisations. Topics include enterprise risk management, treasury management, financial risk instruments and cybersecurity.	{"Enterprise Risk Management (ERM) frameworks — COSO, ISO 31000","Financial risk — interest rate, currency, credit and liquidity risk","Treasury management and hedging strategies","Derivatives — futures, options, swaps and FRAs","Cybersecurity risk and governance","Business continuity and resilience planning"}	🛡️		{"Apply ERM frameworks to identify and prioritise enterprise risks.","Calculate and evaluate strategies for managing financial risks including FX and interest rate risk.","Select and price appropriate derivative instruments for hedging purposes.","Assess cybersecurity risks and recommend governance controls.","Develop and evaluate business continuity and resilience plans."}	Identifying, assessing and managing enterprise-level risk	[{"desc": "Risk identification, assessment, appetite, tolerance and ERM frameworks (COSO, ISO 31000).", "topic": "Enterprise Risk Management"}, {"desc": "Interest rate risk, foreign currency risk, credit risk, liquidity risk and treasury policy.", "topic": "Financial Risks & Treasury"}, {"desc": "Forward contracts, futures, options, swaps and interest rate instruments — calculation and strategy.", "topic": "Hedging Instruments"}, {"desc": "IT governance, cybersecurity frameworks (CISA knowledge), data protection and incident response.", "topic": "Cybersecurity & Technology Risk"}, {"desc": "BCP planning, disaster recovery, resilience strategies and crisis management.", "topic": "Business Continuity"}]	4 Months	{f138287c-529f-42ec-83be-ac13fddfec85}	175
F3	Financial Strategy	25000	strategic	f3-financial-strategy	F3 covers the advanced corporate finance topics required for financial leadership. Students evaluate financing, dividend and investment decisions; value businesses; and advise on mergers, acquisitions and complex financial strategy questions.	{"Capital structure theory — Modigliani-Miller, WACC","Business valuation methods — DCF, multiples, EVA","Dividend policy and payout decisions","Mergers & acquisitions — valuation and financing","Initial Public Offerings (IPOs) and capital markets","International financial management"}	💎		{"Evaluate corporate financing decisions and optimise the capital structure.","Value businesses using multiple approaches and advise on M&A transactions.","Formulate dividend policy recommendations for diverse stakeholder groups.","Advise on the financial strategy for complex international businesses.","Apply advanced corporate finance theory to strategic financial decisions."}	Corporate finance, valuation and strategic financial decision-making	[{"desc": "Sources of finance, capital structure theories, gearing and the cost of capital (WACC).", "topic": "Corporate Financing Decisions"}, {"desc": "Asset-based, income-based (DCF) and market-based valuation methods and their application.", "topic": "Business Valuation"}, {"desc": "M&A rationale, valuation of targets, financing structures, due diligence and integration.", "topic": "Mergers & Acquisitions"}, {"desc": "Dividend theories, payout ratios, scrip dividends, buybacks and signalling.", "topic": "Dividend Policy"}, {"desc": "Cross-border financing, transfer pricing, political risk and international capital markets.", "topic": "International Financial Management"}]	4 Months	{eb5562db-7f3a-4882-95f3-b6b17a0cfe57}	175
SCS	Strategic Case Study	30750	strategic	strategic-case-study	The Strategic Case Study (SCS) is CIMA's most demanding integrated exam, testing mastery of E3, P3 and F3 within a complex, board-level business scenario. Success in the SCS, combined with the CIMA experience requirement, awards the CGMA designation.	{"Integration of E3, P3 and F3 at board level","Complex pre-seen with full organisation simulation","Board-level strategic recommendations and reports","Financial strategy and risk management application","Corporate governance and ethical decision-making"}	🌐		{"Produce board-level strategic reports integrating E3, P3 and F3 knowledge.","Evaluate complex strategic situations and recommend financially sound decisions.","Manage enterprise risk and financial strategy at the highest organisational level.","Apply governance and ethical principles within complex real-world scenarios.","Achieve the CGMA designation upon passing the SCS and fulfilling the experience requirement."}	The final integrated assessment — combining E3, P3 and F3	[{"desc": "In-depth analysis of the pre-seen: industry, competitive position, financial health and strategy.", "topic": "Strategic Position Mastery"}, {"desc": "Using F3 knowledge — valuations, M&A analysis, financing decisions — in the board scenario.", "topic": "Financial Strategy Application"}, {"desc": "P3 frameworks applied to identify, evaluate and manage strategic and financial risks in context.", "topic": "Risk Management Application"}, {"desc": "E3 tools — strategic analysis, competitive positioning, CSR and sustainability in the SCS scenario.", "topic": "Strategic Leadership"}, {"desc": "Full mock SCS exams, marking review with Channa Gunawardana and response structuring workshops.", "topic": "SCS Exam Technique"}]	7 - 8 Weeks	{221aece0-07cd-470f-beba-3014d6a8cb32}	599
BA3	Fundamentals of Financial Accounting	16000	certificate	ba3-fundamentals-of-financial-accounting	BA3 introduces students to financial accounting and the preparation of financial statements. It covers the regulatory framework, accounting principles, double-entry bookkeeping, and the preparation of financial statements for sole traders, partnerships and companies.	{"Double-entry bookkeeping principles","Preparation of trial balance and financial statements","Accounting for assets, liabilities and equity","Accruals, prepayments and provisions","Partnership accounts","Introduction to company accounts"}	📑		{"Apply double-entry bookkeeping to record business transactions accurately.","Prepare trial balances and basic financial statements.","Account for common adjustments such as depreciation and accruals.","Prepare financial statements for partnerships and sole traders.","Understand the basic structure of company financial statements."}	Financial reporting, the accounting equation & double-entry bookkeeping	[{"desc": "The accounting equation, double-entry system and the accounting cycle.", "topic": "Accounting Fundamentals"}, {"desc": "Income statements, balance sheets and cash flow statements for different entity types.", "topic": "Preparing Financial Statements"}, {"desc": "Depreciation, accruals, prepayments, bad debts and provisions.", "topic": "Accounting Adjustments"}, {"desc": "Appropriation accounts, capital and current accounts, admission and retirement of partners.", "topic": "Partnership Accounts"}, {"desc": "Share capital, retained earnings, basic presentation under IFRS.", "topic": "Introduction to Company Accounts"}]	2 - 4 Months	{91e313c1-99f7-41ee-9890-85158ed60f48}	105
Test	test	1000	certificate	test	Test eco	{Econ,Time,Line}			{tes}	Test Economy	[{"desc": "test", "topic": "Test"}]	4 Months	{4ef36cbd-3c0d-4a93-97e8-e70ccd2d38e2,c302c6ea-e1b9-4f59-b876-f43caa33c0aa,49a2c71a-14b9-41a4-a519-61f209131484,91e313c1-99f7-41ee-9890-85158ed60f48}	10
OCS	Operational Case Study	26650	operational	operational-case-study	The Operational Case Study (OCS) is a three-hour integrated assessment that tests students' ability to apply knowledge from E1, F1 and P1 in a realistic business scenario. It assesses professional skills including communication, analysis and judgement.	{"Integration of E1, F1 and P1 knowledge","Realistic business scenario with pre-seen material","Analysis and application of operational finance skills","Professional communication and report writing","Commercial awareness and judgement"}	🏗️		{"Integrate knowledge across E1, F1 and P1 to address complex operational issues.","Analyse a business scenario using financial and non-financial information.","Produce professional-quality written responses tailored to senior management audiences.","Demonstrate commercial awareness and sound business judgement.","Perform effectively under exam conditions with structured time management."}	Integrated assessment combining E1, F1 and P1	[{"desc": "Analysing the case study context, industry, business model and strategic position.", "topic": "Pre-Seen Analysis"}, {"desc": "Applying F1 knowledge to prepare and interpret financial information in context.", "topic": "Financial Reporting Application"}, {"desc": "Using P1 tools for costing, budgeting and performance measurement in the scenario.", "topic": "Management Accounting Application"}, {"desc": "Applying E1 digital concepts within the operational business scenario.", "topic": "Digital Finance in Context"}, {"desc": "Time management, answering variant tasks and presenting professional-quality responses.", "topic": "Exam Technique"}]	7 - 8 Weeks	{c7b4f981-db7d-454f-9bb1-a7062044c181,221aece0-07cd-470f-beba-3014d6a8cb32,d6b07747-c580-4d22-8a87-ba757b43c632}	399
BA1	Fundamentals of Business Economics	16000	certificate	ba1-fundamentals-of-business-economics	BA1 provides a thorough grounding in micro and macroeconomics, exploring how businesses operate within global markets. Students examine the economic environment and its impact on business decisions and performance.	{"Microeconomics — supply, demand and market equilibrium","Macroeconomics — GDP, inflation, interest rates","International trade and globalisation","Business cycles and economic indicators","Government policy and its effects on business","Financial markets and institutions"}	📊		{"Explain the role of markets and pricing mechanisms in resource allocation.","Analyse macroeconomic data and assess the impact on business strategy.","Evaluate international trade patterns and the effects of exchange rate movements.","Understand the function of financial institutions and capital markets.","Apply economic principles to business decision-making scenarios."}	Enterprise, economics & the global business environment	[{"desc": "Understanding how political, economic, social, and technological forces shape the business landscape.", "topic": "The Global Business Environment"}, {"desc": "Supply and demand, price elasticity, market structures and competitive behaviour.", "topic": "Microeconomic Analysis"}, {"desc": "Fiscal and monetary policy tools and their effects on business and investment.", "topic": "Macroeconomic Policy"}, {"desc": "Exchange rates, balance of payments, international trade agreements and protectionism.", "topic": "International Trade & Finance"}, {"desc": "Role of financial intermediaries, capital markets, and the banking system.", "topic": "Financial Markets & Institutions"}]	2 - 4 Months	{49a2c71a-14b9-41a4-a519-61f209131484}	105
BA4	Fundamentals of Ethics, Corporate Governance and Business Law	16000	certificate	ba4-fundamentals-of-ethics-corporate-governance-and-business-law	BA4 provides the ethical and legal grounding that underpins the CIMA qualification. Students study corporate governance frameworks, professional ethics, sustainability and the legal context within which businesses operate.	{"CIMA Code of Ethics and professional conduct","Corporate governance principles and frameworks","Sustainability and integrated reporting","Contract law and employment law basics","Company law and directors' duties","Data protection and cybersecurity awareness"}	⚖️		{"Apply the CIMA Code of Ethics to identify and resolve professional ethical issues.","Explain the principles of good corporate governance and their significance.","Discuss sustainability reporting and integrated thinking.","Understand key elements of contract law and employment law.","Outline the legal duties of company directors and the rights of shareholders."}	Ethics, governance frameworks and the legal context of business	[{"desc": "Ethical frameworks, professional scepticism and resolution of ethical dilemmas.", "topic": "Business Ethics"}, {"desc": "Governance codes, board structures, audit committees and shareholder rights.", "topic": "Corporate Governance"}, {"desc": "<IR> Framework, ESG considerations and non-financial reporting.", "topic": "Sustainability & Integrated Reporting"}, {"desc": "Formation and enforcement of contracts, consumer protection and employment law.", "topic": "Business Law Essentials"}, {"desc": "Company formation, share capital, directors' duties and insolvency basics.", "topic": "Company Law"}]	2 - 4 Months	{4ef36cbd-3c0d-4a93-97e8-e70ccd2d38e2}	105
BA2	Fundamentals of Management Accounting	16000	certificate	ba2-fundamentals-of-management-accounting	BA2 covers the core principles of management accounting, equipping students with skills to gather, analyse and use cost and management information to support planning, control and decision-making within organisations.	{"Cost classification and behaviour","Absorption and marginal costing methods","Budgeting and budgetary control","Standard costing and variance analysis","Cost–volume–profit (CVP) analysis","Decision-making techniques"}	🧮		{"Prepare and interpret cost statements using various costing methods.","Construct and analyse budgets to support financial planning and control.","Calculate and interpret standard cost variances.","Apply relevant costing principles to short-term business decisions.","Understand the role of management accounting in supporting organisational strategy."}	Costing, budgeting and management information systems	[{"desc": "Cost objects, cost classification, direct/indirect costs and cost behaviour.", "topic": "Costing Principles"}, {"desc": "Job, batch, process and service costing, absorption vs marginal costing.", "topic": "Costing Methods"}, {"desc": "Preparing functional and master budgets, flexed budgets and budgetary control.", "topic": "Budgeting"}, {"desc": "Setting standards, calculating variances and interpreting results.", "topic": "Standard Costing"}, {"desc": "CVP analysis, relevant costs, limiting factors and short-run decisions.", "topic": "Decision Making"}]	2 - 4 Months	{c302c6ea-e1b9-4f59-b876-f43caa33c0aa}	105
E3	Strategic Management	25000	strategic	e3-strategic-management	E3 covers the formulation, evaluation and implementation of strategy at the enterprise level. Students analyse the competitive environment, develop strategic options, manage strategic risk and lead organisational change to deliver the strategy.	{"Strategic analysis — PESTLE, Porter's Five Forces, SWOT","Corporate strategy — Ansoff matrix, BCG portfolio","Competitive strategy — differentiation, cost leadership","Innovation and disruptive strategy","Strategic implementation and change management","Corporate social responsibility and sustainability"}	🗺️		{"Conduct comprehensive strategic analysis using key analytical frameworks.","Evaluate strategic options and recommend the most appropriate strategy.","Design strategies for competitive advantage in complex market environments.","Lead strategic implementation including change, culture and performance alignment.","Integrate sustainability and CSR considerations into strategic decision-making."}	Formulating and implementing competitive business strategy	[{"desc": "External environment analysis (PESTLE), industry analysis (Porter's Five Forces) and internal capability assessment.", "topic": "Strategic Position Analysis"}, {"desc": "Growth strategies, diversification, mergers & acquisitions, alliances and corporate portfolio management.", "topic": "Strategic Choices"}, {"desc": "Porter's generic strategies, value chain analysis, resource-based view and dynamic capabilities.", "topic": "Competitive Advantage"}, {"desc": "Disruptive innovation, digital business models and strategic responses to technological change.", "topic": "Innovation & Digital Strategy"}, {"desc": "Change management, organisational alignment, culture, leadership and balanced scorecard.", "topic": "Strategy Implementation"}]	4 Months	{d7106124-ce06-4c47-be01-e017f96e5608}	175
P1	Management Accounting	25000	operational	p1-management-accounting	P1 advances students' management accounting skills, covering advanced costing techniques, pricing strategies, performance measurement, and risk in the context of planning and control within organisations.	{"Activity-based costing (ABC)","Target costing and value engineering","Transfer pricing","Throughput accounting","Pricing strategies","Budgetary control and beyond budgeting"}	📈		{"Apply advanced costing techniques including ABC and throughput accounting.","Make pricing decisions using both cost-based and market-based approaches.","Analyse short-run operational decisions using relevant costing principles.","Design and evaluate budgeting systems appropriate to the organisation.","Select and apply performance measurement frameworks including the balanced scorecard."}	Advanced costing, planning, control and performance measurement	[{"desc": "ABC, throughput accounting, life-cycle costing and target costing.", "topic": "Advanced Costing Techniques"}, {"desc": "Pricing strategies, price elasticity, market-based and cost-plus pricing.", "topic": "Pricing Decisions"}, {"desc": "Relevant costing, limiting factors, make or buy, and shutdown decisions.", "topic": "Short-run Decisions"}, {"desc": "Budgetary systems, beyond budgeting, rolling forecasts and zero-based budgeting.", "topic": "Planning & Budgeting"}, {"desc": "Financial and non-financial KPIs, balanced scorecard, responsibility centres.", "topic": "Performance Management"}]	4 Months	{c302c6ea-e1b9-4f59-b876-f43caa33c0aa}	175
E1	Managing Finance in a Digital World	25000	operational	e1-managing-finance-in-a-digital-world	E1 examines the evolving role of the finance function in a digital business environment. Students explore digital technologies, data analytics, automation and the changing skills required of finance professionals.	{"The digital finance function and its evolution","Data analytics and business intelligence","Automation, RPA and AI in finance","Cloud computing and ERP systems","Cybersecurity and data governance","Digital transformation strategy"}	💻		{"Explain how digital technologies are transforming the finance function.","Evaluate the use of data analytics and automation in financial processes.","Assess the risks and benefits of cloud-based and ERP systems.","Apply principles of data governance and cybersecurity in a finance context.","Support digital transformation initiatives within organisations."}	The role of finance and digital technologies in business	[{"desc": "Role of finance in modern organisations, shared services and finance business partnering.", "topic": "The Finance Function"}, {"desc": "Big data, analytics, automation, AI and machine learning in finance.", "topic": "Digital Technologies"}, {"desc": "ERP systems, cloud computing, data management and governance.", "topic": "Information Systems"}, {"desc": "Cybersecurity risks, data protection regulations and ethical use of data.", "topic": "Data Security & Ethics"}, {"desc": "Supporting digital transformation and change management within finance.", "topic": "Digital Strategy"}]	4 Months	{d7106124-ce06-4c47-be01-e017f96e5608}	175
E2	Managing Performance	25000	management	e2-managing-performance	E2 examines how organisations manage performance and relationships in modern dynamic environments. Students explore project management, people management, digital innovation and the management of change across complex organisations.	{"Organisational structure and governance","Project management methodologies (PRINCE2, Agile)","Stakeholder engagement and communication","Change management models","People management and motivation theories","Managing digital transformation projects"}	🏎️		{"Evaluate organisational structures and governance frameworks.","Plan and manage projects using appropriate methodologies.","Apply people management and change management models in business contexts.","Develop stakeholder communication and engagement strategies.","Manage digital transformation and innovation within finance teams."}	Project management, business relationships and leading change	[{"desc": "Types of organisation, governance frameworks and how structures enable performance.", "topic": "Organisational Structures"}, {"desc": "Project life cycle, planning, scheduling, risk management and benefits realisation.", "topic": "Project Management"}, {"desc": "Leadership styles, motivation theory, managing resistance and organisational change models.", "topic": "People & Change Management"}, {"desc": "Identifying, analysing and communicating with diverse stakeholder groups.", "topic": "Stakeholder Management"}, {"desc": "Managing digital change projects, agile approaches and disruptive innovation.", "topic": "Digital & Innovation"}]	4 Months	{d7106124-ce06-4c47-be01-e017f96e5608}	175
F1	Financial Reporting	25000	operational	f1-financial-reporting	F1 develops students' ability to prepare and interpret financial statements for individual companies and groups in accordance with IFRS. Topics include consolidation, financial instruments and reporting frameworks.	{"IFRS conceptual framework","Preparation of single entity financial statements","Group accounts — consolidation basics","Revenue recognition (IFRS 15)","Leases (IFRS 16)","Financial instruments overview"}	📋		{"Prepare financial statements for single entities in accordance with IFRS.","Construct basic consolidated financial statements including goodwill calculations.","Apply key IFRS standards including IFRS 15, 16 and IFRS 9.","Analyse and interpret financial statements using key ratios.","Explain the role and authority of the IASB and national standard setters."}	Preparation and analysis of financial statements under IFRS	[{"desc": "IASB conceptual framework, qualitative characteristics and the standard-setting process.", "topic": "The Financial Reporting Framework"}, {"desc": "P&L, OCI, balance sheet, cash flow statement and notes under IFRS.", "topic": "Single Entity Financial Statements"}, {"desc": "Consolidation, elimination of intra-group transactions, goodwill and non-controlling interests.", "topic": "Group Accounts"}, {"desc": "IFRS 15 (Revenue), IFRS 16 (Leases), IFRS 9 (Financial Instruments).", "topic": "Key IFRS Standards"}, {"desc": "Ratio analysis, horizontal/vertical analysis and limitations of financial statements.", "topic": "Interpretation & Analysis"}]	4 Months	{d6b07747-c580-4d22-8a87-ba757b43c632}	175
\.


--
-- Data for Name: enrollment_reminders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enrollment_reminders (id, enrollment_id, reminder_number, sent_at) FROM stdin;
9485f194-9aa9-4d99-8c61-776d39b7e5c1	c360790d-607d-4406-9825-2e02d973c253	1	2026-03-24 15:30:00.442
b7bed7ad-c54b-4cb5-b7e5-01056f676629	979fc84c-af88-4a0b-bbc7-5805b832c321	1	2026-03-24 15:30:00.623
8225d198-98e0-4eeb-a8ab-c10f5f8640a2	792f1a61-d81d-46ea-b081-963e0bfa7a2c	1	2026-03-24 15:30:00.734
fe35be52-e1f3-4bab-960f-9fc39bab4d9b	c0a9e279-d6a1-46e2-8afd-f9bb76a48b4f	1	2026-03-24 15:30:00.87
dbdbc531-82bf-4d3f-a995-32718afc104b	7ef760bb-9eb2-49bf-8fd3-4b12fcc7370b	1	2026-03-24 15:30:00.925
aaff874d-1e7d-4eb5-a546-38330ae9207e	6476d1fc-84bd-4dae-a6b1-fb05b232ff0f	1	2026-03-24 15:30:00.986
083e17d0-8afd-4f83-b5ae-91ec55a0e23d	b889b033-754a-4097-a2a9-1182c251f795	1	2026-03-24 15:30:01.059
954839af-48bb-4eb4-9744-4aa871778b61	11b786f5-8be8-4c8b-9fac-8e5ae3fec19f	1	2026-03-24 15:30:01.217
f96be547-9b56-4065-8bd4-4c6050f6d711	50a3dd0e-ca29-4397-a88a-af23581c4b3a	1	2026-03-24 15:30:01.343
d64a7db2-0f78-4fda-ac69-4073061e163a	99094e4d-b7eb-4d89-b61f-070790fbdeb9	1	2026-03-24 15:30:01.622
223c661b-e5e3-40ec-b264-4d2c67411127	078bb7b7-93ed-42d4-918c-02d108b977cc	1	2026-03-24 15:30:01.868
cffef85b-6f34-4e7d-a824-788f623bb404	b376a4b3-1301-40cf-ab39-61a98bbf1190	1	2026-03-24 15:30:02.008
a932d130-2b90-4c84-a450-f2582494e04e	eeec7cae-406c-468c-b168-ef73b760a632	1	2026-03-24 15:30:02.101
088a4134-bbcf-4775-99eb-2f439617dd31	11d57de2-3ab8-4621-bedb-74f3bdcb620b	1	2026-03-24 15:30:02.339
eb2119f9-216f-4d4f-bc3c-34d529f537d1	b4c78d07-f80b-4b83-a714-1c7520e1277b	1	2026-03-24 15:30:02.391
fd77cb32-e5cd-4af8-a0d8-bf01c1f4219e	c360790d-607d-4406-9825-2e02d973c253	2	2026-03-24 16:30:00.441
c8de922c-0513-4f2a-b68b-9d71a6bf2a8a	979fc84c-af88-4a0b-bbc7-5805b832c321	2	2026-03-24 16:30:00.61
4932f776-5d59-4c21-86fc-428ef2a74ec4	792f1a61-d81d-46ea-b081-963e0bfa7a2c	2	2026-03-24 16:30:00.669
e1a00f8b-df75-4382-9ca7-618ebb6b3665	c0a9e279-d6a1-46e2-8afd-f9bb76a48b4f	2	2026-03-24 16:30:00.748
c271de4e-0e35-4c06-b22e-759e73cb26c4	7ef760bb-9eb2-49bf-8fd3-4b12fcc7370b	2	2026-03-24 16:30:00.82
5be0e5e5-1cf0-4282-b71f-52dc40eb0f8b	6476d1fc-84bd-4dae-a6b1-fb05b232ff0f	2	2026-03-24 16:30:00.873
0d756a63-8cc3-4bf5-aaec-436201ef579f	b889b033-754a-4097-a2a9-1182c251f795	2	2026-03-24 16:30:00.947
3c19c763-5a09-442d-a3d9-c65260413131	11b786f5-8be8-4c8b-9fac-8e5ae3fec19f	2	2026-03-24 16:30:01.003
95c006b1-2983-4778-923e-a1a55901b34d	50a3dd0e-ca29-4397-a88a-af23581c4b3a	2	2026-03-24 16:30:01.092
23f15bbc-d7ed-42c4-86ea-0c2d33b565ad	99094e4d-b7eb-4d89-b61f-070790fbdeb9	2	2026-03-24 16:30:01.159
d1c5059c-9d7c-48b3-8a10-0259043ae0a4	078bb7b7-93ed-42d4-918c-02d108b977cc	2	2026-03-24 16:30:01.271
84d7138b-1ae6-468f-9227-e7f7e67de1ba	b376a4b3-1301-40cf-ab39-61a98bbf1190	2	2026-03-24 16:30:01.332
6046c1d3-2e37-4524-816f-a89443bec64b	eeec7cae-406c-468c-b168-ef73b760a632	2	2026-03-24 16:30:01.386
90a1ca24-c965-4bb4-a0d7-585b21f30269	11d57de2-3ab8-4621-bedb-74f3bdcb620b	2	2026-03-24 16:30:01.448
490d78e7-a4dc-438f-a21f-2ab6f811ce71	b4c78d07-f80b-4b83-a714-1c7520e1277b	2	2026-03-24 16:30:01.515
a6ef297e-22c5-4bb5-a33d-16e27af62e4b	ef856b29-31c8-43e8-bf3e-8b244a7d38fa	1	2026-03-25 10:30:00.211
9cf68552-05f1-4df8-9c24-8d9605879f81	63097b78-75f7-43aa-ac1d-e23e8ba6e4c9	1	2026-03-25 16:30:00.194
bf0df3ef-b1d4-48ba-9607-3787d0f8bdfc	d94bd118-1b11-48a6-aaed-9b7f6638f25a	1	2026-03-25 16:30:00.321
beee0d82-731e-47b6-8f8b-198c45c51163	75774b55-f6b6-467c-9997-f0936db162f2	1	2026-03-25 16:30:00.444
ba6419fd-a6be-469a-b624-36064f6b273f	d7157282-0288-480d-9cca-2e780799b9fb	1	2026-03-25 16:30:00.527
c71afaed-4fc7-4b22-9bc7-9019ebdd2dae	6d2d8bb8-8581-4364-971e-7630a73703c7	1	2026-03-25 18:30:00.27
72ff96a6-d46c-44f5-ae5a-6209a83ebdec	ef856b29-31c8-43e8-bf3e-8b244a7d38fa	2	2026-03-26 10:30:00.201
156eb273-76b0-4272-a3af-63687e3137e7	13a14023-f76c-4a48-a5c2-01c6d6f0b56e	1	2026-03-26 13:30:00.357
ee439ef7-1770-4299-b609-3d449b8113cd	1c40637e-bad5-45aa-b5b2-64cf0984a96d	1	2026-03-26 13:30:00.515
ff59ded8-8aee-4c4b-a376-8c74affd2a63	c360790d-607d-4406-9825-2e02d973c253	3	2026-03-26 15:30:00.528
5aa81bf0-7cd9-4acd-87a5-2d58b8e8062f	979fc84c-af88-4a0b-bbc7-5805b832c321	3	2026-03-26 15:30:00.7
f7e04de5-1d00-44b7-b384-29eb21ad8ec0	792f1a61-d81d-46ea-b081-963e0bfa7a2c	3	2026-03-26 15:30:00.777
c5870ece-8dbe-4a40-bbf3-02d99b16821e	c0a9e279-d6a1-46e2-8afd-f9bb76a48b4f	3	2026-03-26 15:30:00.855
4e6812b5-d902-4bb9-928e-3572ecb50e78	7ef760bb-9eb2-49bf-8fd3-4b12fcc7370b	3	2026-03-26 15:30:01.005
f434ac28-766e-4a5f-83a6-9f2dcb047381	6476d1fc-84bd-4dae-a6b1-fb05b232ff0f	3	2026-03-26 15:30:01.13
5e8829cd-1c23-4f2d-acaf-4b628d82a269	b889b033-754a-4097-a2a9-1182c251f795	3	2026-03-26 15:30:01.473
2ddf1ab0-0b87-4d29-8e3a-6e35027a4401	11b786f5-8be8-4c8b-9fac-8e5ae3fec19f	3	2026-03-26 15:30:02.101
5b674fad-0acf-42c8-9484-33678958fcb1	50a3dd0e-ca29-4397-a88a-af23581c4b3a	3	2026-03-26 15:30:02.352
79084509-ebed-413f-a762-f33311b0dcb4	99094e4d-b7eb-4d89-b61f-070790fbdeb9	3	2026-03-26 15:30:02.781
ad2be6bc-b722-4e09-a9b4-d2fc68c896b7	078bb7b7-93ed-42d4-918c-02d108b977cc	3	2026-03-26 15:30:03.113
f0287ddd-42f1-496f-a3a8-1c74cd24b7a6	b376a4b3-1301-40cf-ab39-61a98bbf1190	3	2026-03-26 15:30:03.209
35da0909-081f-43ca-80f6-118b9e5458b3	eeec7cae-406c-468c-b168-ef73b760a632	3	2026-03-26 15:30:03.298
06361c43-8600-4466-a7f0-647121112cf3	11d57de2-3ab8-4621-bedb-74f3bdcb620b	3	2026-03-26 15:30:03.486
c86ee853-dc73-4e40-b323-5318860a1c96	b4c78d07-f80b-4b83-a714-1c7520e1277b	3	2026-03-26 15:30:03.569
3fe1eb08-a727-4e5e-bd19-441e72ad4f5b	464caa4c-803c-417b-be8e-4984bb96105a	1	2026-03-26 15:30:03.669
3ab11890-fbc2-41b6-8eb4-25fbb9d1bbd9	1404538c-3e33-401b-9988-8fae305a7e3c	1	2026-03-26 15:30:03.824
0ebc95c4-fda2-4014-a948-71b71497e2f7	820f45cf-a9ca-4372-ac66-7db9819749ef	1	2026-03-26 15:30:03.92
ddf87f6a-548b-43e8-8a18-1f4a528215ce	c0fe8ffe-a19c-4681-8890-569393189db6	1	2026-03-26 15:30:04.057
e3005902-813e-4c2a-9c29-3681ae78b665	9d18ccfa-fd25-49dd-a3cc-093b60e2ca2e	1	2026-03-26 15:30:04.133
2a8bd23f-0ad8-4ebd-a1b8-1cb8eac10db3	b6bf1dc6-8202-4f58-ac75-772c4d62c60c	1	2026-03-26 15:30:04.25
23220d11-0766-4956-ba1e-d9eb1107ecc0	35dc268c-0bab-4d55-a042-4c1873e20ee4	1	2026-03-26 15:30:04.438
32d0e36e-9051-4235-9e50-99b5b54b1c58	9880d5e9-fbbd-4f6b-a969-59e330fedac0	1	2026-03-26 15:30:04.49
2236a0dc-f89c-4dd1-8d42-a14ceb5aa8be	b49f5b29-1f21-4e3c-b1d1-82cab37dba1f	1	2026-03-26 15:30:04.566
4daef814-9d33-42c9-b16f-92f09375d15c	849104a7-42c2-45c0-b161-30953e0f1b28	1	2026-03-26 15:30:04.64
e5ab59fd-6309-44f5-b164-85eb2e7cb8ed	63097b78-75f7-43aa-ac1d-e23e8ba6e4c9	2	2026-03-26 16:30:00.246
7093a409-c3ca-4b96-8da8-956bb730eed5	d94bd118-1b11-48a6-aaed-9b7f6638f25a	2	2026-03-26 16:30:00.364
71fd6557-35ae-43cd-87ab-a8bd25f0024c	75774b55-f6b6-467c-9997-f0936db162f2	2	2026-03-26 16:30:00.415
8d2afa81-ea0d-4e7d-b0f5-45ac2b36941a	d7157282-0288-480d-9cca-2e780799b9fb	2	2026-03-26 16:30:00.812
79bfbaea-b89d-4f81-b558-4775fdf01003	6d2d8bb8-8581-4364-971e-7630a73703c7	2	2026-03-26 18:30:00.312
b9f0f5da-c467-438a-a224-7a2cafdfef7e	e6e49e8a-d0ba-432e-9c76-cd8e9520898b	1	2026-03-27 07:30:00.304
d8741e3a-ad60-4865-bf6b-721b141baf9a	0d9079a3-6282-45f4-9401-640d75ba42bd	1	2026-03-27 07:30:00.415
a27aac16-26fa-4d3b-9d64-585428e5d379	63d9ab80-7299-4f4d-890f-e025b7c0f7c4	1	2026-03-27 10:30:00.134
b7c07f1c-44e5-407a-816e-9eb6ae87831c	6440b785-47ec-4914-b610-2e8c485843c8	1	2026-03-27 10:30:00.201
5f2f7df6-0e2f-45d5-adb0-fd4437ad11e9	f75ab5f7-8f82-40df-8cca-015fc963a817	1	2026-03-27 10:30:00.276
5b9fb5d2-afb5-4b5e-825b-11b7d6d4c37b	2c0ef893-d4d4-41c2-a825-a48cf5d085eb	1	2026-03-27 10:30:00.326
54372653-3da2-4ea5-aa32-b96d4893f387	58cdbde3-6657-4da7-9fd7-5dbefe8a4752	1	2026-03-27 10:30:00.402
fdaa2167-7373-42fa-8a00-d7bf3d09559a	5a290895-0374-4830-b390-3534da0b1a32	1	2026-03-27 10:30:00.473
98a85d33-2af4-486f-8f08-6a370a2443a1	70b84b4f-c69a-4366-9e55-facea61a6bed	1	2026-03-27 10:30:00.515
2b204100-9297-4216-8d20-b8d852dcfaf4	3bfa6850-949d-4bdb-9805-74bf3c72dd9a	1	2026-03-27 11:30:00.16
7f896d95-e34f-403d-b08f-b913b7cd435d	a8c56ac1-825f-49bd-9c12-40cd4519620d	1	2026-03-27 11:30:00.215
5ffc6490-9aae-4c79-bdf1-27ad9d8d0508	8c2d1384-e5a0-4ac8-8c9d-82aa5a1d4849	1	2026-03-27 12:30:00.249
21ad570e-8565-4895-8924-cb4aeadb3be4	0cee5ffc-dcf8-40cd-8199-be74963667d4	1	2026-03-27 12:30:00.408
ad7300d0-c33d-44dd-a1e0-158850843dc0	3cdb0ef7-9667-4b7c-ba0f-b130eaa6a32b	1	2026-03-27 13:30:00.23
e05a5af6-f68d-4d56-a7ad-f99d8533e85a	8d315827-1480-4a50-a18c-b288c9a46000	1	2026-03-27 14:30:00.476
4fcd3158-5dbc-4f56-8365-9e7011012d71	82a813e3-81dc-49bd-939d-25885ea870a9	1	2026-03-27 18:30:00.339
281178fe-270c-4b05-abb4-96b9fe2e5750	bb8b8927-4cb6-46f3-aa7b-eabe51af3a5e	1	2026-03-27 18:30:00.438
ed05d63a-03b2-484d-b400-14a2db984ed5	84ab5202-b674-47a0-889d-034949d49757	1	2026-03-27 18:30:00.493
8b59cb65-d281-4dff-893f-cf1511a05ff2	1334a386-3e0d-4865-abd9-ec96d8487c3a	1	2026-03-28 02:30:00.203
\.


--
-- Data for Name: enrollment_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enrollment_submissions (id, first_name, last_name, email, phone, whatsapp, cima_id, cima_stage, dob, gender, country, city, postcode, notes, cart_json, currency, amount, order_id, created_at) FROM stdin;
c360790d-607d-4406-9825-2e02d973c253	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:01.063
979fc84c-af88-4a0b-bbc7-5805b832c321	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:27.845
792f1a61-d81d-46ea-b081-963e0bfa7a2c	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:28.751
c0a9e279-d6a1-46e2-8afd-f9bb76a48b4f	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:29.751
7ef760bb-9eb2-49bf-8fd3-4b12fcc7370b	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:29.968
6476d1fc-84bd-4dae-a6b1-fb05b232ff0f	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:30.744
b889b033-754a-4097-a2a9-1182c251f795	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:30.968
11b786f5-8be8-4c8b-9fac-8e5ae3fec19f	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:54.742
50a3dd0e-ca29-4397-a88a-af23581c4b3a	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:56.6
99094e4d-b7eb-4d89-b61f-070790fbdeb9	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:57.586
078bb7b7-93ed-42d4-918c-02d108b977cc	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:57:57.802
b376a4b3-1301-40cf-ab39-61a98bbf1190	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:58:14.179
eeec7cae-406c-468c-b168-ef73b760a632	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 14:58:59.81
11d57de2-3ab8-4621-bedb-74f3bdcb620b	Dasuni	Illankoon	dasuniillankoon@gmail.com	076 748 4500	\N	402551496	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 15:02:43.902
b4c78d07-f80b-4b83-a714-1c7520e1277b	Dasuni	Illankoon	dasuniillankoon@gmail.com	0767484500	\N	\N	Operational Level	2001-04-04	Female	Sri Lanka	Nugegoda	10250	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-22 15:04:41.379
ef856b29-31c8-43e8-bf3e-8b244a7d38fa	Shihaab	Inshaff	inshaff2@gmail.com	0772908790	0772908790	\N	Certificate Level	2009-01-18	Male	Sri Lanka	Colombo	11300	\N	[{"type": "level", "levelId": "certificate", "priceGbp": 360, "priceLkr": 55000, "levelPath": "/cima-certificate-level", "levelTitle": "CIMA Certificate Level", "courseCount": 4, "combinationId": "cert_full"}]	LKR	55000	\N	2026-03-24 09:37:58.176
a8e5904d-5a90-4576-82ca-fc8434993747	Lisa 	Boateng 	lisaboatengk@gmail.com	+233201197705	+233 201197705	402489535	Operational	1999-05-19	Female	GHANA 	Koforidua 	EN-011-1653	Ghanaian student 	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 20:54:17.242
63097b78-75f7-43aa-ac1d-e23e8ba6e4c9	Tatum	Arnold	xarorive@mailinator.com	+1 (419) 786-8474	+1 (608) 457-6196	\N	Management Level	1987-01-09	Prefer not to say	Canada	Culpa ut similique 	Nulla consequatur li	Odio illum est quae	[{"type": "level", "levelId": "certificate", "priceGbp": 360, "priceLkr": 64000, "levelPath": "/cima-certificate-level", "levelTitle": "CIMA Certificate Level", "courseCount": 4, "combinationId": "cert_full"}, {"slug": "p1-management-accounting", "type": "course", "levelId": "operational", "priceGbp": 200, "priceLkr": 149, "courseCode": "P1", "courseName": "Management Accounting", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	GBP	560	\N	2026-03-24 15:35:24.49
d94bd118-1b11-48a6-aaed-9b7f6638f25a	Tatum	Arnold	xarorive@mailinator.com	+1 (419) 786-8474	+1 (608) 457-6196	\N	Management Level	1987-01-09	Prefer not to say	Canada	Culpa ut similique 	Nulla consequatur li	Odio illum est quae	[{"type": "level", "levelId": "certificate", "priceGbp": 360, "priceLkr": 64000, "levelPath": "/cima-certificate-level", "levelTitle": "CIMA Certificate Level", "courseCount": 4, "combinationId": "cert_full"}, {"slug": "p1-management-accounting", "type": "course", "levelId": "operational", "priceGbp": 200, "priceLkr": 149, "courseCode": "P1", "courseName": "Management Accounting", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	GBP	560	\N	2026-03-24 15:35:37.655
75774b55-f6b6-467c-9997-f0936db162f2	Tatum	Arnold	xarorive@mailinator.com	+1 (419) 786-8474	+1 (608) 457-6196	\N	Management Level	1987-01-09	Prefer not to say	Canada	Culpa ut similique 	Nulla consequatur li	Odio illum est quae	[{"type": "level", "levelId": "certificate", "priceGbp": 360, "priceLkr": 64000, "levelPath": "/cima-certificate-level", "levelTitle": "CIMA Certificate Level", "courseCount": 4, "combinationId": "cert_full"}, {"slug": "p1-management-accounting", "type": "course", "levelId": "operational", "priceGbp": 200, "priceLkr": 149, "courseCode": "P1", "courseName": "Management Accounting", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	GBP	560	\N	2026-03-24 15:35:38.309
d7157282-0288-480d-9cca-2e780799b9fb	Tatum	Arnold	xarorive@mailinator.com	+1 (419) 786-8474	+1 (608) 457-6196	\N	Management Level	1987-01-09	Prefer not to say	Canada	Culpa ut similique 	Nulla consequatur li	Odio illum est quae	[{"type": "level", "levelId": "certificate", "priceGbp": 360, "priceLkr": 64000, "levelPath": "/cima-certificate-level", "levelTitle": "CIMA Certificate Level", "courseCount": 4, "combinationId": "cert_full"}]	GBP	360	\N	2026-03-24 15:35:42.629
6d2d8bb8-8581-4364-971e-7630a73703c7	Priscilla	Harvey	qopyr@mailinator.com	+1 (166) 344-9223	+1 (791) 727-2021	\N	Operational Level	1997-05-28	Prefer not to say	Other	Rerum voluptates ess	Sed voluptates et er	Temporibus eum accus	[{"type": "level", "levelId": "certificate", "priceGbp": 360, "priceLkr": 64000, "levelPath": "/cima-certificate-level", "levelTitle": "CIMA Certificate Level", "courseCount": 4, "combinationId": "cert_full"}]	GBP	360	\N	2026-03-24 18:19:29.165
13a14023-f76c-4a48-a5c2-01c6d6f0b56e	Dawn	Wheeler	qolufysof@mailinator.com	+1 (395) 154-2017	Corrupti et alias u	Ullamco ad expedita 	Strategic	2017-09-28	Male	Non omnis quo conseq	Est id culpa est a	Esse sunt blanditiis	Ut voluptatem ad aut	[{"id": "custom-link", "name": "Cert"}]	GBP	800	\N	2026-03-25 12:57:34.265
1c40637e-bad5-45aa-b5b2-64cf0984a96d	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	Management Level	2026-03-25	Male	Malaysia	343	343	\N	[{"slug": "ba1-fundamentals-of-business-economics", "type": "course", "levelId": "certificate", "priceGbp": 105, "priceLkr": 149, "courseCode": "BA1", "courseName": "Fundamentals of Business Economics", "levelTitle": "CIMA Certificate Level", "combinationId": ""}]	GBP	105	\N	2026-03-25 13:26:15.108
464caa4c-803c-417b-be8e-4984bb96105a	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	\N	\N	\N	2002-01-16	Female	Sri Lanka	Colombo 05	00500	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 14:57:19.109
1404538c-3e33-401b-9988-8fae305a7e3c	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	\N	\N	\N	2002-01-16	Female	Sri Lanka	Colombo 05	00500	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 14:57:39.16
820f45cf-a9ca-4372-ac66-7db9819749ef	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	\N	\N	\N	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 14:57:47.03
c0fe8ffe-a19c-4681-8890-569393189db6	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	\N	\N	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 14:58:00.9
9d18ccfa-fd25-49dd-a3cc-093b60e2ca2e	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	\N	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 14:59:52.057
b6bf1dc6-8202-4f58-ac75-772c4d62c60c	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	0715473388	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 15:00:15.012
35dc268c-0bab-4d55-a042-4c1873e20ee4	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	0715473388	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 15:00:15.367
9880d5e9-fbbd-4f6b-a969-59e330fedac0	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	0715473388	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 15:00:15.57
b49f5b29-1f21-4e3c-b1d1-82cab37dba1f	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	0715473388	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 15:00:15.767
849104a7-42c2-45c0-b161-30953e0f1b28	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	0715473388	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	-	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 149, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	149	\N	2026-03-25 15:00:15.901
e6e49e8a-d0ba-432e-9c76-cd8e9520898b	HOANG VU 	TRAN	erichoangtran@gmail.com	+61434488188										[{"id": "custom-link", "name": "Case Study - Re sit GBP"}]	GBP	185	\N	2026-03-26 06:34:58.768
0d9079a3-6282-45f4-9401-640d75ba42bd	Tawakaltu 	Raji	raji_tawa@yahoo.com											[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-26 06:50:03.484
63d9ab80-7299-4f4d-890f-e025b7c0f7c4	Vindya	Deshapriya	vindyavimukthini@gmail.com	0701267642	0701267642	402610822	Operational Level	2002-09-07	Female	Sri Lanka	Kurunegala	60040	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-26 10:00:06.808
6440b785-47ec-4914-b610-2e8c485843c8	Vindya	Deshapriya	vindyavimukthini@gmail.com	0701267642	0701267642	402610822	Operational Level	2002-09-07	Female	Sri Lanka	Kurunegala	60040	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-26 10:00:34.06
f75ab5f7-8f82-40df-8cca-015fc963a817	Vindya	Deshapriya	vindyavimukthini@gmail.com	0701267642	0701267642	402610822	Operational Level	2002-09-07	Female	Sri Lanka	Kurunegala	60040	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-26 10:02:20.877
2c0ef893-d4d4-41c2-a825-a48cf5d085eb	Vindya	Deshapriya	vindyavimukthini@gmail.com	0701267642	0701267642	\N	Operational Level	2002-09-07	Female	Sri Lanka	Kurunegala	60040	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-26 10:03:45.778
58cdbde3-6657-4da7-9fd7-5dbefe8a4752	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-26 10:21:11.038
5a290895-0374-4830-b390-3534da0b1a32	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-26 10:23:05.691
70b84b4f-c69a-4366-9e55-facea61a6bed	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-26 10:27:00.485
3bfa6850-949d-4bdb-9805-74bf3c72dd9a	Vindya	Deshapriya	vindyavimukthini@gmail.com	0701267642	0701267642	402610822	Operational Level	2002-09-07	Female	Sri Lanka	Kurunegala	60040	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-26 10:35:45.572
a8c56ac1-825f-49bd-9c12-40cd4519620d	Michael	Amoah	michaelamoah100@gmail.com	+233248610969										[{"id": "custom-link", "name": "MCS - Ghana"}]	GBP	185	\N	2026-03-26 10:59:06.48
8c2d1384-e5a0-4ac8-8c9d-82aa5a1d4849	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-26 12:11:06.421
0cee5ffc-dcf8-40cd-8199-be74963667d4	Habib	Lamin	habibullah.lh46@gmail.com	+233558293278	0558293278	402588770	Operational	1985-01-13	Male	Ghana	Bechem			[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-26 12:15:00.005
3cdb0ef7-9667-4b7c-ba0f-b130eaa6a32b	Akalanka	Ranasinghe	akalanka@nanaska.com	+94 77 584 4677	\N	\N	\N	\N	Male	Sri Lanka	Colombo	00300	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-26 13:19:53.272
8d315827-1480-4a50-a18c-b288c9a46000	Pavithra	Kailaivasan	pkailaivasan@gmail.com	0710470769	0710470769	1-2Z0T32R 	Management Level	1997-09-12	Female	Sri Lanka	Kandy	20000	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-26 14:00:52.679
82a813e3-81dc-49bd-939d-25885ea870a9	Baheerathan	Thillaiampalam	bahee@dmsswe.com	+94777224589	+94777224589	1-FGFT	Strategic Level	1969-09-26	Male	Sri Lanka	Nugegoda	10250	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-26 17:56:11.276
bb8b8927-4cb6-46f3-aa7b-eabe51af3a5e	Thillaiampalam 	 Baheerathan	bahee@dmsswe.com	+94777224589	+94777224589	1-FGFT	Strategic Level	1969-09-26	Male	Sri Lanka	Nugegoda	10250	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-26 18:00:00.77
84ab5202-b674-47a0-889d-034949d49757	Baheerathan	Thillaiampalam	bahee@dmsswe.com	0777224589	0777224589	1-FGFT	Strategic Level	1969-09-26	Male	Sri Lanka	Nugegoda	10250	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-26 18:02:52.049
1334a386-3e0d-4865-abd9-ec96d8487c3a	Pavithra	Kailaivasan	pkailaivasan@gmail.com	0710470769	\N	\N	\N	\N	\N	Sri Lanka	Kandy	20000	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-27 01:52:19.591
217c897b-624b-4077-9bab-10b8794947c8	Vindya	Deshapriya	vindyavimukthini@gmail.com	0701267642	0701267642	402610822	\N	2002-09-07	Female	Sri Lanka	Kurunegala	60040	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-27 02:44:20.381
379c43c8-9569-4541-a868-b7a6fdffe66c	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana 2"}]	GBP	85	\N	2026-03-27 06:40:10.36
4e29e7c3-9d5b-420e-9867-f72789a5969c	Pavithra	Kailaivasan	pkailaivasan@gmail.com	0710470769	0710470769	\N	\N	\N	\N	Sri Lanka	Kandy	20000	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-27 08:10:24.936
1b1c1fd4-54cb-4f5c-b3c6-578bf411e79e	Akalanka	Ranasinghe	akalanka@nanaska.com	0775844677	\N	\N	\N	\N	Male	Sri Lanka	Colombo	00300	\N	[{"slug": "ba4-fundamentals-of-ethics-corporate-governance-and-business-law", "type": "course", "levelId": "certificate", "priceGbp": 105, "priceLkr": 16000, "courseCode": "BA4", "courseName": "Fundamentals of Ethics, Corporate Governance and Business Law", "levelTitle": "CIMA Certificate Level", "combinationId": ""}]	LKR	16000	\N	2026-03-27 09:51:02.77
0150e361-60cb-4ed1-afe0-960c4410168e	H	A Wathsala	wathsala@nanaska.com	0773669817	\N	\N	\N	\N	Male	Sri Lanka	BORALESGAMUWA	10290	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-27 10:27:01.638
8d52c080-fc4e-4660-9bb6-c46c5e2dbd14	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana 2"}]	GBP	85	\N	2026-03-27 11:15:25.483
9245d131-3cf5-4f5d-b5c6-159833fce8c4	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana 2"}]	GBP	85	\N	2026-03-27 11:15:35.578
33feefd3-40a8-402d-aac5-f41f627fd520	Tawakaltu 	Raji	raji_tawa@yahoo.com	0242763834										[{"id": "custom-link", "name": "OCS - Ghana 2"}]	GBP	85	\N	2026-03-27 11:18:56.872
7490b3d5-c50e-46b2-ac29-be5d88081db0	Niranjala 	Samanthi	r.a.n.samanthi@gmail.com	+94758004281										[{"id": "custom-link", "name": "OCS - Re sit SL"}]	LKR	23985	\N	2026-03-27 11:46:40.132
562a6767-1645-4871-87fe-3c87e9604882	Wathsala	Gunawardana	wathsala@nanaska.com	0773669817	\N	\N	\N	\N	Male	Sri Lanka	Boralesgamuwa	10120	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-27 12:48:14.091
e1617e90-ee4f-407b-98e5-e14b41d8ef5c	Baheerathan	Thillaiampalam	bahee@dmsswe.com	0777224589	0777224589	\N	Strategic Level	1969-09-26	Male	Sri Lanka	Nugegoda	10250	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-27 13:29:49.998
69024cc8-f309-4882-b564-2d531c9e5041	Kelly	Suarez	ryjomesy@mailinator.com	+1 (961) 947-7672	+1 (363) 538-3426	\N	Strategic Level	1996-07-28	Female	Canada	Maiores vero qui con	Atque odio nemo itaq	Et tenetur eos qui 	[{"slug": "f2-advanced-financial-reporting", "type": "course", "levelId": "management", "priceGbp": 175, "priceLkr": 25000, "courseCode": "F2", "courseName": "Advanced Financial Reporting", "levelTitle": "CIMA Management Level", "combinationId": ""}]	GBP	175	\N	2026-03-27 13:38:59.074
54d38bd9-8e05-4403-825d-8cd7443f9322	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	343	343	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}, {"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	58425	\N	2026-03-27 18:33:23.736
28384826-4de0-45e8-9b9d-8b2566d407b7	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	343	343	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-27 18:33:32.331
f1aedbfc-539b-479e-a62d-4a177f216b65	Ruvini	Dias	ruvinidias96@gmail.com	768502428	0768502428	402765315	Operational	1996-11-25						[{"id": "custom-link", "name": "OCS - Re sit SL"}]	LKR	23985	\N	2026-03-28 02:57:09.089
b29dbd0e-8f93-4946-b775-7cb9cb737a11	Carlos	Slater	lepugid@mailinator.com	+1 (463) 636-4359	+1 (292) 802-6567	In dolore incidunt 	Strategic Level	2018-06-03	Male	Sri Lanka	Nesciunt adipisci a	Debitis aut nemo eni	Commodo qui rerum es	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}, {"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	58425	\N	2026-03-28 03:17:47.421
d754c668-5207-434a-94de-7d5490346262	Nethma	Karunatilleke	nethmat16@gmail.com	0715473388	\N	402477829	Operational Level	2002-01-16	Female	Sri Lanka	Colombo 05	00500	\N	[{"slug": "operational-case-study", "type": "course", "levelId": "operational", "priceGbp": 399, "priceLkr": 26650, "courseCode": "OCS", "courseName": "Operational Case Study", "levelTitle": "CIMA Operational Level", "combinationId": ""}]	LKR	26650	\N	2026-03-28 03:55:24.649
51c94a42-c79c-4fbd-8593-0b6c6ab81fbf	Chathura 	Athukorala	chathuraathukorala1@gmail.com	+94773813669										[{"id": "custom-link", "name": "OCS - Re sit SL"}]	LKR	23985	\N	2026-03-28 05:04:49.307
cdab2995-f05c-416d-9f77-7dfc4bf0a3b5	H	A Wathsala	wathsala@nanaska.com	0773669817	\N	\N	\N	\N	Male	Sri Lanka	BORALESGAMUWA	10290	\N	[{"slug": "strategic-case-study", "type": "course", "levelId": "strategic", "priceGbp": 599, "priceLkr": 30750, "courseCode": "SCS", "courseName": "Strategic Case Study", "levelTitle": "CIMA Strategic Level", "combinationId": ""}]	LKR	30750	\N	2026-03-28 08:16:11.316
b1791007-f20b-4eea-812a-a16c096853b1	Lisa 	Boateng 	lisaboatengk@gmail.com	+233201197705	+233 201197705	402489535	Operational	1999-05-19	Female	GHANA 	Koforidua 	EN-011-1653	Ghanaian student 	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 20:55:06.149
7757c04f-5a62-4b36-87ad-7be897f27d44	Vinumi	De Silva	vvds2006@gmail.com	0777031686	0777031686	1-7MXDYQ0	Management Level	2006-10-11	Female	Sri Lanka	Panadura	12500	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-28 09:32:57.151
f1e6709e-f976-447d-ba05-84fa246c34a3	Vinumi	De Silva	vvds2006@gmail.com	0777031686	0777031686	1-7MXDYQ0	Management Level	2006-10-11	Female	Sri Lanka	Panadura	12500	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-28 09:32:57.463
6541d708-e801-4563-bfba-8647b27947fa	Vinumi	De Silva	vvds2006@gmail.com	0777031686	0777031686	1-7MXDYQ0	Management Level	2006-10-11	Female	Sri Lanka	Panadura	12500	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-28 09:36:53.104
178c8936-6896-465b-81e7-be71c8422ee8	Vinumi	De Silva	vvds2006@gmail.com	0777031686	0777031686	1-7MXDYQ0	Management Level	2006-10-11	Female	Sri Lanka	Panadura	12500	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-28 09:36:53.258
eb71bef8-f6ba-4333-b54d-af49b9798460	Chandima 	Senevirathne 	chandinep1@gmail.com	0714346356	0714346356	1-259DKSJ	Management Level	1987-03-26	Female	Sri Lanka	Gampaha	11000	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-28 09:55:27.393
b0c397a1-5081-4625-b4d4-0cc895dc8d5d	Shimla	Uvaim	shimlauvaim@gmail.com	0756695367	\N	402631217	Management Level	2003-09-25	Female	Sri Lanka	Galle	80000	\N	[{"slug": "management-case-study", "type": "course", "levelId": "management", "priceGbp": 499, "priceLkr": 27675, "courseCode": "MCS", "courseName": "Management Case Study", "levelTitle": "CIMA Management Level", "combinationId": ""}]	LKR	27675	\N	2026-03-28 11:05:37.456
acc95ed5-0d96-4f42-ab71-88505b0f4e59	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:32:26.662
55e4d0e2-301a-41a0-a3a7-7cd85aa2fe72	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:32:29.204
4af6a68b-318c-4dc4-ba5d-af28b8eef8c2	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:36:56.073
2c521795-edaa-47f4-b38c-25bc9a55282b	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:37:55.088
305969c3-b57c-4e9d-93cd-cb73c415218a	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:37:55.414
1de56eb6-dd68-44f5-9462-c6aabf89fbed	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:38:46.955
11f90043-330b-42b4-aab7-ce46c66247bc	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}]	LKR	75000	\N	2026-03-28 11:39:58.262
34026303-5b8d-47a3-8e5c-79391171b4a9	Miyuru	Dharmage	channa@nanaska.com	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:40:48.614
8277d8ba-52f3-4d5c-891a-8905c28221ab	Lisa 	Boateng	lisaboatengk@gmail.com	+233 201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana	Koforidua	GA247	None	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 22:30:26.465
8151e64e-35e3-4612-982f-2dd89462eadb	Shelby	Witt	jukaqexoh@mailinator.com	+1 (633) 276-6086	+1 (843) 177-6977	\N	Operational Level	1997-12-26	Prefer not to say	Other	Qui et neque consequ	Pariatur Quo est f	Aute quia ratione qu	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	GBP	1200	\N	2026-03-28 11:41:04.252
cb044c1b-a598-4f07-884f-3be5a19d0e24	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Other	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	GBP	1200	\N	2026-03-28 11:50:42.329
157b71e7-41cf-4f1f-8ace-89c857c79b66	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Other	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	GBP	1200	\N	2026-03-28 11:50:43.265
e588f1ec-e8e1-4206-ab21-6fb49be774b1	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Other	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	GBP	1200	\N	2026-03-28 11:50:50.978
f9ae0e6a-380d-4466-8d94-9187fe29a44e	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Other	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	GBP	1200	\N	2026-03-28 11:51:00.772
ec61859d-2c7f-4f50-b1d8-ed2e525239c6	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Other	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	GBP	1200	\N	2026-03-28 11:53:50.62
9a4cf24b-27d2-42ba-a581-99f9d0eae17f	Miyuru	Dharmage	admin@theredsun.org	077 439 5913	\N	\N	\N	\N	\N	Sri Lanka	Attidiya	343	\N	[{"type": "level", "levelId": "operational", "priceGbp": 600, "priceLkr": 75000, "levelPath": "/cima-operational-level", "levelTitle": "CIMA Operational Level", "courseCount": 4, "combinationId": "op_full"}, {"type": "level", "levelId": "management", "priceGbp": 600, "priceLkr": 77775, "levelPath": "/cima-management-level", "levelTitle": "CIMA Management Level", "courseCount": 4, "combinationId": "mg_full"}]	LKR	152775	\N	2026-03-28 11:55:20.54
1234a4bb-e70e-4cab-8572-6aa70d3d9ba6	chaminda	Marasinghe	chamiprabath2003@gmail.com	+94771052926										[{"id": "custom-link", "name": "OCS Re sit"}]	LKR	22500	\N	2026-03-29 08:23:18.548
9df8d6a6-a046-4242-96ca-73219f64d20e	Chaminda	Marasinghe	chamiprabath2003@gmail.com	771052926										[{"id": "custom-link", "name": "OCS Re sit"}]	LKR	22500	\N	2026-03-29 09:00:03.615
3c86844d-b59f-4bef-9989-e3a8b214e2c3	Rudolf	Hammelburg	olandeananda@gmail.com	+94773508384										[{"id": "custom-link", "name": "OCS Re sit"}]	LKR	22500	\N	2026-03-29 09:21:04.501
d1348fe5-c43d-4982-a29b-c5a4d015fa90	JOSEPH	CHAONSA	jchaonsa6@gmail.com	+260977788661	+260977788661	402543821‎	Strategic	1979-02-20	Male	Zambia	LUSAKA	10101	none	[{"id": "custom-link", "name": "SCS - Ghana"}]	GBP	185	\N	2026-03-29 19:00:10.988
94ed7935-e335-423b-b9be-886b73ce422a	Anuththara	Sewmini	anus36642@gmail.com	+94777289832										[{"id": "custom-link", "name": "OCS - Re sit SL"}]	LKR	23985	\N	2026-03-30 07:52:35.496
adf8a641-6575-4c40-9594-cb0c0968ea51	Lisa	Boateng 	lisaboatengk@gmail.com	+233201197705	+233201197705	402489535	Operational	1999-05-19	Female	Ghana 	Koforidua 	EN-011-4492	Eastern Region 	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 09:34:02.565
5d9cdc6f-6d3b-45f7-a0e0-9cabec7b7b4f	Lisa	Boateng	lisaboatengk@gmail.com	+233201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana				[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 19:30:50.341
9b6ae269-f4c7-4de7-9ad4-c7668ab4a339	Lisa	Boateng	lisaboatengk@gmail.com	+233201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana				[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 19:32:57.309
cc6c267c-4608-4dc3-bec4-5c315a26cb7b	Lisa 	Boateng	lisaboatengk@gmail.com	+233 201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana				[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 19:36:04.105
24635a78-6ded-4006-96a8-e8d151d2d50c	Lisa 	Boateng	lisaboatengk@gmail.com	+233 201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana	Koforidua	GA247		[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 19:38:30.388
a842b47a-ca99-482f-be64-7b3de8c5aa45	Lisa 	Boateng	lisaboatengk@gmail.com	+233 201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana	Koforidua	GA247	None	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 20:42:51.119
d09fdf70-c2be-46bb-ba46-484e191af8b8	Lisa 	Boateng	lisaboatengk@gmail.com	+233 201197705	+233 201197705	402489535	Operational	1999-05-19	Female	Ghana	Koforidua	GA247	None	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 20:43:27.356
e5c0f8ef-1343-483e-a1e6-79f77ebad700	Lisa 	Boateng 	lisaboatengk@gmail.com	+233201197705	+233 201197705	402489535	Operational	1999-05-19	Female	GHANA 	Koforidua 	EN-011-1653	Ghanaian student 	[{"id": "custom-link", "name": "OCS - Ghana"}]	GBP	85	\N	2026-03-30 20:54:01.078
\.


--
-- Data for Name: lecturers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lecturers (id, name, title, credentials, bio, bio2, image_url, stats, specialties, sort_order, active, created_at, updated_at) FROM stdin;
c7b4f981-db7d-454f-9bb1-a7062044c181	Mark Gunathilake	Lecturer – P2, OCS & BA2	{"BSc Hons (USJ)",ACMA,CGMA,"SCS Prize Winner"}	Mark Gunathilake is a Passed Finalist of the Chartered Institute of Management Accountants. He also holds a 1st Class Bachelor's Degree in Accountancy from the University of Sri Jayewardenepura.	Having started off his career at one of the big 4 audit firms, he brings over 3 years of experience across Manufacturing, Transportation and Retail. As a former CIMA SCS Prize Winner, he gives students a unique practical edge in their preparation.	/images/2025-01-Untitled-design-11.png	[{"label": "SCS Prize Winner", "number": "🥇"}, {"label": "OCS & BA2", "number": "P2"}, {"label": "Alumni", "number": "Big 4"}]	{"P2 Management Accounting","OCS Case Study",BA2}	6	t	2026-03-20 08:07:09.957	2026-03-29 03:13:08.089
d6b07747-c580-4d22-8a87-ba757b43c632	Osmand Fernando	Lecturer	{"MBA (UK)",ACMA,CGMA}	Osmand Fernando holds an MBA from the United Kingdom and ACMA/CGMA qualifications, bringing international perspective and professional finance expertise to Nanaska students.	His international academic background combined with professional qualifications equips him to deliver high-quality, globally-relevant CIMA tuition.	/images/2024-07-IMG_6966-1copy.png	[{"label": "UK Qualified", "number": "MBA"}, {"label": "CGMA", "number": "ACMA"}, {"label": "International", "number": "🌐"}]	{"Management Accounting","Financial Strategy","Business Analysis"}	7	t	2026-03-20 08:07:09.967	2026-03-29 03:13:08.099
91e313c1-99f7-41ee-9890-85158ed60f48	Shervin Perera	Lecturer – F2 & BA3	{"ACMA (UK)",CGMA,"MBA (UOS)"}	Shervin Perera holds impressive credentials including ACMA (UK), CGMA, and an MBA from the University of Southampton. His extensive expertise in management accounting and business analysis is invaluable as he teaches the F2 and BA3 subjects.	Mr. Perera's commitment to academic excellence and practical insights will greatly benefit students, equipping them with the knowledge and skills needed to excel in their professional careers.	/images/2024-06-Shervin_Perera-removebg-preview.png	[{"label": "Specialist", "number": "F2"}, {"label": "Univ. Southampton", "number": "MBA"}, {"label": "UK Qualified", "number": "ACMA"}]	{"F2 Advanced Financial Reporting",BA3,"Management Accounting"}	5	t	2026-03-20 08:07:09.947	2026-03-29 03:13:08.074
d7106124-ce06-4c47-be01-e017f96e5608	Aloka Seneviratne	Lecturer – E3 Strategic Management	{"CIMA Passed Finalist",DipM,"BSc Hons Engineering Physics"}	Praveen Aloka Seneviratne brings a wealth of knowledge and experience, holding a BSc Hons in Engineering Physics along with credentials as a CIMA Passed Finalist and DipM. His diverse academic background and professional expertise make him a valuable asset to the Nanaska faculty.	Aloka's dedication to education and his ability to convey complex concepts with clarity will undoubtedly inspire and empower students. He is the E3 lecturer at Nanaska.	/images/2024-07-DSC_0454-Copy-1.png	[{"label": "Specialist", "number": "E3"}, {"label": "Passed Finalist", "number": "CIMA"}, {"label": "Engineering Physics", "number": "BSc"}]	{"E3 Strategic Management","Business Strategy",Leadership}	2	t	2026-03-20 08:07:09.917	2026-03-29 03:13:08.108
c302c6ea-e1b9-4f59-b876-f43caa33c0aa	Ali Raheem	Lecturer – BA2	{"BSc (USJ)","CIMA Exams Complete"}	Ali Raheem is a CIMA passed finalist, having completed the qualification within a span of 2 years. He is a product of St. Peter's College, Colombo and is currently an Undergraduate at the University of Sri Jayewardenepura.	Ali has been an assistant lecturer at Nanaska since 2019 and he is the BA2 lecturer at Nanaska.	/images/2025-01-Untitled-design-13.png	[{"label": "CIMA Completed", "number": "2yrs"}, {"label": "Specialist", "number": "BA2"}, {"label": "At Nanaska", "number": "2019"}]	{"BA2 Management Accounting","Business Economics"}	11	t	2026-03-20 08:07:09.999	2026-03-29 03:13:08.115
def01bf9-8fb4-44b0-8b91-8a9c0f7f628e	Lasantha Vidanagamage	Lecturer – P2 Advanced Management Accounting	{"CIMA Passed Finalist","MPAcc (USJ)","BPharm (USJ)"}	Lasantha Vidanagamage is a CIMA pass finalist and holds both a Master of Professional Accounting (MPAcc) and a Bachelor of Pharmacy (BPharm) from the University of Sri Jayewardenepura.	He teaches P2 – Advanced Management Accounting. His diverse academic background and extensive expertise in management accounting provide students with a comprehensive and practical learning experience.	/images/2024-07-441312389_467371879000666_851286037044610417_n-copy-1.png	[{"label": "Specialist", "number": "P2"}, {"label": "USJ Graduate", "number": "MPAcc"}, {"label": "Passed Finalist", "number": "CIMA"}]	{"P2 Advanced Management Accounting"}	8	t	2026-03-20 08:07:09.976	2026-03-29 03:13:08.121
4ef36cbd-3c0d-4a93-97e8-e70ccd2d38e2	Janith Jayasinghe	Lecturer – Law & HRM	{"LB (Hons)","Affiliate CIPM",Attorney-at-Law,"Notary Public","Company Secretary"}	Janith Jayasinghe is a multifaceted professional excelling in both the legal and human resources domains. Holding an LB (Hons) degree and a Professional Qualification in HRM from CIPM, he is an Attorney-at-Law, Notary Public, Commissioner for Oaths, and a Company Secretary.	As an Affiliate CIPM, Janith brings a unique blend of legal expertise and HR management proficiency, making him a well-rounded professional in his field.	/images/2025-01-Untitled-design-15.png	[{"label": "Honours", "number": "LLB"}, {"label": "Affiliate", "number": "CIPM"}, {"label": "Attorney-at-Law", "number": "⚖️"}]	{"Business Law","Corporate Governance",HRM,Ethics}	10	t	2026-03-20 08:07:09.993	2026-03-29 03:13:08.127
221aece0-07cd-470f-beba-3014d6a8cb32	Channa Gunawardana	Lead Lecturer & CEO	{"CIMA Fellow","CA Sri Lanka","MBA Finance","PhD (Candidate)"}	Channa Gunawardana, CEO of a public listed company in Sri Lanka, is a fellow member of CIMA UK and CA Sri Lanka. He holds a Bachelor's degree in Accountancy and Financial Management from the University of Sri Jayewardenepura and an MBA in Finance from the University of Southern Queensland, Australia. He is currently pursuing a PhD at Management and Science University, Malaysia.	With 21 years of lecturing experience, he is renowned as the CIMA case study specialist, having produced over 95% of CIMA Sri Lanka prize winners, including global prize winners over the last decade. He is also a member of the CIMA Global Council.	/images/2021-04-Channa.png	[{"label": "Years Lecturing", "number": "21+"}, {"label": "Prize Winners", "number": "95%"}, {"label": "Global Winners", "number": "10+"}]	{"CIMA Case Study","Strategic Level","Management Level","Operational Level"}	1	t	2026-03-20 08:07:09.896	2026-03-29 03:13:08.133
f138287c-529f-42ec-83be-ac13fddfec85	Indika Rajakaruna	Lecturer – P3 Risk Management	{"CISA – ISCA (USA)","AIB (IBSL)","PG Ex.Dip Bank Mgt","Executive MSc Marketing"}	Indika Rajakaruna is a banker by profession in the Governance, Risk and Control field who counts over 25 years of exposure in the banking industry. He currently leads a team of audit professionals in a listed bank awarded both titles of Best Bank and Best Digital Bank in Sri Lanka.	He is the First and Only Accredited Trainer in Sri Lanka for the CISA (Certified Information Systems Auditor) by ISACA–USA, and serves as Director for Corporate Relations of ISACA–Sri Lanka Chapter. He covers Cyber Risk within P3 at Nanaska.	/images/2021-04-Indika.png	[{"label": "Years in Banking", "number": "25+"}, {"label": "CISA Trainer SL", "number": "#1"}, {"label": "Risk Specialist", "number": "P3"}]	{"P3 Risk Management",Cybersecurity,"IS Auditing","Enterprise Risk"}	3	t	2026-03-20 08:07:09.929	2026-03-29 03:13:08.139
49a2c71a-14b9-41a4-a519-61f209131484	Sanuda Minuraka	Lecturer – BA1	{"BSc Hons 1st Class (Plymouth UK)","CIMA Passed Finalist"}	Sanuda Minuraka holds a First-Class Honors degree in Accounting & Finance from Plymouth University, UK, reflecting his academic excellence and in-depth knowledge of the field.	As a CIMA Passed Finalist, Sanuda combines his strong theoretical foundation with practical insights into management accounting, making his teaching highly engaging and relevant to real-world applications.	/images/2025-01-Untitled-design-12.png	[{"label": "Class Hons (UK)", "number": "1st"}, {"label": "Specialist", "number": "BA1"}, {"label": "Passed Finalist", "number": "CIMA"}]	{"BA1 Business Economics","Management Accounting"}	9	t	2026-03-21 09:42:24.033	2026-03-29 03:13:08.145
eb5562db-7f3a-4882-95f3-b6b17a0cfe57	Ruchira Perera	Lecturer – F3 Financial Strategy	{"BSc Accountancy (USJ)","First Class MBA (PIM)",ACMA,CPA,"FCMA (SL)"}	Mr. Ruchira Perera is a graduate of the University of Sri Jayewardenepura with a first class in Accountancy and Financial Management. He holds an MBA from the Postgraduate Institute of Management and is professionally qualified with CPA (Australia), CIMA (UK) and CMA (SL).	He has nearly two decades of industry experience in senior roles including CFO and Financial Controller. He is a Governing Council Member of CMA Sri Lanka and a Technical Advisor to SAFA, and is pursuing his Doctorate at Lincoln University College, Malaysia.	/images/2022-05-ruchi-1.png	[{"label": "Years in Finance", "number": "18+"}, {"label": "Multinational Exp.", "number": "CFO"}, {"label": "Specialist", "number": "F3"}]	{"F3 Financial Strategy","Corporate Finance",M&A,"Capital Markets"}	4	t	2026-03-20 08:07:09.938	2026-03-29 03:13:08.15
\.


--
-- Data for Name: newsletter_signups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.newsletter_signups (id, email, name, created_at) FROM stdin;
63540766-e637-45a4-bdce-8fac741986a6	miyuru@theredsun.org	\N	2026-03-20 18:37:39.335
3f48bdc5-2585-4dda-bb19-cc08c16e413d	hecuvitiko@mailinator.com	\N	2026-03-24 15:35:01.645
5b997b7f-0a21-484e-be07-f6adefba1d96	branavannthananjayan@gmail.com	\N	2026-03-25 04:27:19.492
c198b6ff-b994-40cb-95ac-9055ccd627df	akalanka@nanaska.com	\N	2026-03-25 07:45:39.17
54988939-976a-4fb7-bdf5-5db07ee0e05c	xav.o.r.i.f.elo.j.a.75@gmail.com	\N	2026-03-26 01:52:22.154
3d7bf30f-c9f9-4b70-8cfc-3baa8e66f1a9	denethivithasha2005@gmail.com	\N	2026-03-28 10:26:02.181
926fe008-53b9-4397-a062-e0420447251a	chamiprabath2003@gmail.com	\N	2026-03-29 07:43:04.056
b420327e-2bd6-4db7-8097-70362b13d43c	sasinipremachandra2001@gmail.com	\N	2026-03-31 08:05:49.42
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, user_id, combination_id, amount, status, ipg_merchant_ref, ipg_ref, created_at, updated_at, guest_email, guest_name, guest_phone, currency, frontend_origin, archived_at, payment_link_id) FROM stdin;
5a54c3e8-5b1d-4b98-a38b-0a3ae2b785a5	\N	cert_full	64000	PENDING	NAN-1773915387607-0C418D81	\N	2026-03-19 10:16:27.61	2026-03-19 10:16:27.61	qupyfyzape@mailinator.com	Gavin Fitzpatrick	+1 (398) 867-2998	LKR	\N	\N	\N
b3ee0ff8-9da9-4b65-8004-70d9ddd3ec3d	\N	cert_full	64000	PENDING	NAN-1773915711781-D77189F0	\N	2026-03-19 10:21:51.783	2026-03-19 10:21:51.783	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
d98dd904-484b-423f-95f5-ed332d3ec24e	\N	cert_full	64000	PENDING	NAN-1773915716289-6275A81E	\N	2026-03-19 10:21:56.291	2026-03-19 10:21:56.291	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
f75dc7ab-f9f3-4acb-b10e-c36be1533214	\N	cert_full	64000	PENDING	NAN-1773916520609-881E61B1	\N	2026-03-19 10:35:20.611	2026-03-19 10:35:20.611	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
c61af2e6-afc2-48ee-ba44-dfb94991b055	\N	cert_full	64000	PENDING	NAN-1773916531430-FCD55685	\N	2026-03-19 10:35:31.431	2026-03-19 10:35:31.431	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
fdf4debd-88f4-4fc7-afa5-8a7a609c3e1b	\N	cert_full	64000	PENDING	NAN-1773916535137-DB410BEA	\N	2026-03-19 10:35:35.139	2026-03-19 10:35:35.139	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
b1e1a958-6525-4220-83ed-0cef6ee15cba	\N	cert_full	64000	PENDING	NAN-1773916555409-E5A9548A	\N	2026-03-19 10:35:55.41	2026-03-19 10:35:55.41	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
b76f14fc-fc41-4e7e-8264-4dca404151ef	\N	cert_full	64000	PENDING	NAN-1773916585778-0FCE3532	\N	2026-03-19 10:36:25.78	2026-03-19 10:36:25.78	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
d47176e8-3204-4072-a919-bc4a5c2563b1	\N	cert_full	64000	PENDING	NAN-1773916589700-3433AC36	\N	2026-03-19 10:36:29.702	2026-03-19 10:36:29.702	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
af49f0a9-bf5b-4bbc-90f3-3b845d0a06a4	\N	cert_full	64000	PENDING	NAN-1773916591016-5C1B394B	\N	2026-03-19 10:36:31.018	2026-03-19 10:36:31.018	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
107768d2-7d50-4ccc-bf21-f24ab9fcedd5	\N	cert_full	64000	PENDING	NAN-1773916593531-0B7B09F9	\N	2026-03-19 10:36:33.532	2026-03-19 10:36:33.532	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
4d82877a-9f41-4d63-a637-5c4a3c69e306	\N	cert_full	64000	PENDING	NAN-1773916595017-3ED78EA5	\N	2026-03-19 10:36:35.018	2026-03-19 10:36:35.018	daho@mailinator.com	Sopoline Goff	+1 (614) 798-1214	LKR	\N	\N	\N
7ae893a6-c756-4aa5-9b7f-6377b57fc975	\N	cert_full	64000	PENDING	NAN-1773916663655-9276214C	\N	2026-03-19 10:37:43.656	2026-03-19 10:37:43.656	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
f7d1c506-4b4b-4e6a-a14b-c75cbb12e8e4	\N	cert_full	64000	PENDING	NAN-1773917179331-D47C8966	\N	2026-03-19 10:46:19.333	2026-03-19 10:46:19.333	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
09f36f74-3564-4f14-abcf-5ae181b81796	\N	cert_full	64000	PENDING	NAN-1773917923404-60D7AAA4	\N	2026-03-19 10:58:43.406	2026-03-19 10:58:43.406	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
ae382fb4-f9d9-4a37-9997-2794776ed01e	\N	cert_full	64000	PENDING	NAN-1773918060459-71484C31	\N	2026-03-19 11:01:00.463	2026-03-19 11:01:00.463	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
059a3aa3-3ddb-4a05-8ad6-e9c0db195ac1	\N	cert_full	64000	PENDING	NAN-1773918152059-0008D815	\N	2026-03-19 11:02:32.06	2026-03-19 11:02:32.06	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
2dc8bb43-e9c0-4d99-8e02-f78b0b3884e6	\N	cert_full	64000	PENDING	NAN-1773918162225-EB0F4E8F	\N	2026-03-19 11:02:42.228	2026-03-19 11:02:42.228	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
d4ccaa5a-de17-49b9-a495-3373a68abe57	\N	cert_full	64000	PENDING	NAN-1773918278545-FC84BD12	\N	2026-03-19 11:04:38.546	2026-03-19 11:04:38.546	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
b448432d-a65e-4eb1-bd2e-946a405daafc	\N	cert_full	64000	PENDING	NAN-1773918287515-CE0F54C0	\N	2026-03-19 11:04:47.517	2026-03-19 11:04:47.517	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
31bbf273-437f-4d43-916f-4b38b64f0df2	\N	cert_full	64000	PENDING	NAN-1773919076031-DF4CD159	\N	2026-03-19 11:17:56.033	2026-03-19 11:17:56.033	kusogyji@mailinator.com	Keegan Olsen	+1 (389) 267-6919	LKR	\N	\N	\N
93eee489-2fca-4513-8ab0-fa65add0a6bf	\N	cert_full	64000	PENDING	NAN-1773919132482-7DFE9938	\N	2026-03-19 11:18:52.484	2026-03-19 11:18:52.484	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
decc841a-79b6-4fc1-ad02-6e262d209c9e	\N	cert_full	64000	PENDING	NAN-1773919895219-D3CE8671	\N	2026-03-19 11:31:35.222	2026-03-19 11:31:35.222	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
190b50de-2d2f-41c0-8c6a-17f94711c963	\N	cert_full	64000	PENDING	NAN-1773920493618-90156217	\N	2026-03-19 11:41:33.62	2026-03-19 11:41:33.62	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
9babe88f-ac80-45db-b6ff-668f2f0be7bb	\N	cert_full	64000	PENDING	NAN-1773920610369-6CE0D21D	\N	2026-03-19 11:43:30.371	2026-03-19 11:43:30.371	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
b473687c-eb99-4ea6-90c3-f2cfd714896e	\N	cert_full	64000	PENDING	NAN-1773920619242-48E0522F	\N	2026-03-19 11:43:39.244	2026-03-19 11:43:39.244	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
ff58dc13-9e94-40f2-9d97-c36d4d4f6e84	\N	cert_full	64000	PENDING	NAN-1773920637093-4A9F8720	\N	2026-03-19 11:43:57.094	2026-03-19 11:43:57.094	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
cd10af08-1ff2-46c1-a6cf-ca528384fe78	\N	cert_full	64000	PENDING	NAN-1773920643044-8E036CC5	\N	2026-03-19 11:44:03.046	2026-03-19 11:44:03.046	ruzola@mailinator.com	Lawrence Hines	+1 (489) 352-5388	LKR	\N	\N	\N
16eeee32-bf16-4a51-89fc-1c38661ea748	\N	cert_full	64000	PENDING	NAN-1773921297993-324F1249	\N	2026-03-19 11:54:57.996	2026-03-19 11:54:57.996	nytyd@mailinator.com	Guinevere Henderson	+1 (993) 971-3877	LKR	\N	\N	\N
ad416228-6dc7-4c53-bc54-32f48df48961	\N	cert_full	64000	PENDING	NAN-1773921303011-24A62B3D	\N	2026-03-19 11:55:03.013	2026-03-19 11:55:03.013	nytyd@mailinator.com	Guinevere Henderson	+1 (993) 971-3877	LKR	\N	\N	\N
ac981c14-c78b-4604-94ff-c5bfaf118102	\N	cert_full	64000	PENDING	NAN-1773921311525-C2652242	\N	2026-03-19 11:55:11.527	2026-03-19 11:55:11.527	nytyd@mailinator.com	Guinevere Henderson	+1 (993) 971-3877	LKR	\N	\N	\N
e220c10f-7796-4f03-a3c4-5e497efdddfb	\N	cert_full	64000	PENDING	NAN-1773921332468-9E73E541	\N	2026-03-19 11:55:32.469	2026-03-19 11:55:32.469	nytyd@mailinator.com	Guinevere Henderson	+1 (993) 971-3877	LKR	\N	\N	\N
06b891e3-e698-405d-8e73-15df90ae69b5	\N	cert_full	64000	PENDING	NAN-1773921504461-956C95E7	\N	2026-03-19 11:58:24.464	2026-03-19 11:58:24.464	nytyd@mailinator.com	Guinevere Henderson	+1 (993) 971-3877	LKR	\N	\N	\N
63581c59-461b-445c-aa44-9426e03faa2e	\N	cert_full	64000	PENDING	NAN-1773921972581-ABA06854	\N	2026-03-19 12:06:12.583	2026-03-19 12:06:12.583	nytyd@mailinator.com	Guinevere Henderson	+1 (993) 971-3877	LKR	\N	\N	\N
deb6a648-59e6-4ff6-bae5-f83df844ae36	\N	cert_full	64000	PENDING	NAN-1773944572217-7DFBD94F	W0bJiDYPST2s2HEis6Rv	2026-03-19 18:22:52.22	2026-03-19 18:22:52.677	jynybamyja@mailinator.com	Buckminster Lambert	+1 (645) 955-3082	LKR	\N	\N	\N
7b498ed6-39ac-4768-a908-ae38335973fc	\N	cert_full	64000	PENDING	NAN-1773945678030-C8F0056A	nhhjX9idTZeDqJQsWkJs	2026-03-19 18:41:18.033	2026-03-19 18:41:18.353	noboroko@mailinator.com	Cain Byers	+1 (803) 371-5122	LKR	\N	\N	\N
242b5ff8-6cce-4efc-a7e8-8fab6f2a2e9e	\N	cert_full	64000	PENDING	NAN-1773945715380-F96F5E24	OPYuVY6RTPOBtjGweq3h	2026-03-19 18:41:55.382	2026-03-19 18:41:55.595	gycewu@mailinator.com	Zia Frye	+1 (416) 124-3007	LKR	\N	\N	\N
2df56012-57bd-48b7-b195-278ac924c21d	\N	cert_full	64000	PENDING	NAN-1773947027987-9EEBEAD4	zUrJ7T1bRVOMbiJNKnhW	2026-03-19 19:03:47.989	2026-03-19 19:03:48.664	moquziza@mailinator.com	Illiana Daniels	+1 (912) 654-4939	LKR	\N	\N	\N
d5934480-b5f7-4189-8a77-3eebcb30d3cc	\N	cert_full	64000	PENDING	NAN-1773947077163-3DECB5E6	aMoG0dg8ROG5sCfuDFfF	2026-03-19 19:04:37.165	2026-03-19 19:04:37.404	secasec@mailinator.com	Tatum Gomez	+1 (623) 793-9126	LKR	\N	\N	\N
54adccb5-533f-46e7-acd3-f4c27827b510	\N	cert_full	64000	PENDING	NAN-1773947174975-8B4B0C8F	sMTAUgLqRUKVrRTb48wp	2026-03-19 19:06:14.976	2026-03-19 19:06:15.262	tohyzizace@mailinator.com	Indira Head	+1 (754) 147-7842	LKR	\N	\N	\N
d13002ff-f011-4225-8579-ee1b6e8c5094	\N	mg_full	110000	PENDING	NAN-1773977660828-D7D166B0	NqRcXB18SWyD9ekn0zqS	2026-03-20 03:34:20.831	2026-03-20 03:34:21.136	qogofijotu@mailinator.com	Drake Vaughan	+1 (571) 975-4081	LKR	\N	\N	\N
5ef9a428-4ad1-440c-bcb7-8a0b62461a34	\N	mg_mcs	40000	PENDING	NAN-1773979779361-32C9C00D	xASTML83T2y4ZwJ4Yi4W	2026-03-20 04:09:39.363	2026-03-20 04:09:39.672	akalankaramesh@gmail.com	Akalanka ranasinghe	0775844677	LKR	\N	\N	\N
21f27300-09d5-4980-81c2-8443a98ee108	\N	cert_ba1	16000	PENDING	NAN-1773982578865-C022F077	Pfwimgu7Tl21AFAemU4g	2026-03-20 04:56:18.868	2026-03-20 04:56:19.285	hemozusif@mailinator.com	Allistair Kidd	+1 (171) 435-9999	LKR	\N	\N	\N
6e8deda9-90fd-4b20-9286-ee624126cbeb	\N	cert_ba1	16000	PENDING	NAN-1773982947664-76CC0D1F	YLZtImeNRci7xWKbuRWx	2026-03-20 05:02:27.665	2026-03-20 05:02:27.958	nihykyqen@mailinator.com	Odysseus Brown	+1 (506) 181-7763	LKR	\N	\N	\N
0f26a1f5-20ef-47a3-b38c-26ff4e73cea3	\N	cert_test	100	PENDING	NAN-1774024655566-BDADBFC3	3on2Os5vRdykVsKF3WLJ	2026-03-20 16:37:35.568	2026-03-20 16:37:35.915	zoriguge@mailinator.com	Eliana Lott	+1 (994) 802-5312	GBP	\N	\N	\N
a796b900-1133-4aa9-a6d2-e0c394ada846	\N	cert_ba1	105	PENDING	NAN-1774445175515-471D8B76	ATqBTkpgSjaixQpMbvEp	2026-03-25 13:26:15.516	2026-03-25 13:26:15.836	admin@theredsun.org	Miyuru Dharmage	077 439 5913	GBP	https://nanaska.com	\N	\N
94011e47-45c8-4890-819a-eef475f29907	\N	cert_test	100	FAILED	NAN-1774024750533-A6C922C4	zPGy9FSpReOd5wUa21X0	2026-03-20 16:39:10.534	2026-03-20 16:40:54.868	cevehy@mailinator.com	Abigail Keller	+1 (187) 992-8595	LKR	\N	\N	\N
ab8b2fae-6828-485c-8c48-05c712028aa7	\N	cert_test	100	FAILED	NAN-1774025225171-006E27DD	eIJYcBFTQuax3GgaOjzs	2026-03-20 16:47:05.172	2026-03-20 16:48:29.318	holufisuxa@mailinator.com	Timon Chan	+1 (457) 438-6595	GBP	\N	\N	\N
f9b20ce5-4c66-417c-9153-3d57dc8f8e35	\N	cert_test	1000	PENDING	NAN-1774025720488-39AE6413	4SzdyxqHTkCArvDilIvj	2026-03-20 16:55:20.49	2026-03-20 16:55:20.837	qywuxeg@mailinator.com	Ina Harris	+1 (359) 367-8626	GBP	https://deluxe-smakager-4e60b2.netlify.app	\N	\N
346ab099-db43-40e1-88a0-3c4853f6700a	\N	cert_test	1000	PAID	NAN-1774025753113-0C85351D	XP7nqqr4QVCFXPO0BLRd	2026-03-20 16:55:53.114	2026-03-20 16:57:04.049	zuvimiku@mailinator.com	Gavin Lamb	+1 (364) 635-5813	LKR	https://deluxe-smakager-4e60b2.netlify.app	\N	\N
aceda20e-6b70-4891-aa74-ca9b032c1a5e	\N	cert_full	55000	PENDING	NAN-1774345078582-64C5E4F1	QvNKGoZHT4uKl0akgWCP	2026-03-24 09:37:58.585	2026-03-24 09:37:59.335	inshaff2@gmail.com	Shihaab Inshaff	0772908790	LKR	https://nanaska.com	\N	\N
1e8f21d1-2eb3-4293-82cc-c6ac64864abc	\N	cert_full	360	PENDING	NAN-1774366542997-79B976A6	4dDNar7yRzibLCA6evGh	2026-03-24 15:35:42.999	2026-03-24 15:35:43.474	xarorive@mailinator.com	Tatum Arnold	+1 (419) 786-8474	GBP	https://nanaska.com	\N	\N
6a137bc8-b095-40aa-a86c-cba017aa9264	\N	cert_full	360	PENDING	NAN-1774376369579-DBA1D54B	C3Tv1M1cTTS5CBLTxLBH	2026-03-24 18:19:29.582	2026-03-24 18:19:30.012	qopyr@mailinator.com	Priscilla Harvey	+1 (166) 344-9223	GBP	https://nanaska.com	\N	\N
c185ce71-26cd-45ff-80ca-5c6d1cfb5094	\N	\N	185	PAID	NAN-1774506898781-3A909A49	PetTtPGUQTKsBDOoBMBT	2026-03-26 06:34:58.786	2026-03-26 06:37:15.951	erichoangtran@gmail.com	HOANG VU  TRAN	+61434488188	GBP	https://nanaska.com	\N	a2ffbc7a-67d7-4420-83c2-f850b770d521
b7569307-1c1a-4546-bddc-fbff87d37d29	\N	\N	800	PENDING	NAN-1774443454270-B501987D	Mv1M0AVHROCMLHOv9JfS	2026-03-25 12:57:34.272	2026-03-25 12:57:34.702	qolufysof@mailinator.com	Dawn Wheeler	+1 (395) 154-2017	GBP	https://nanaska.com	\N	\N
ce97a507-68c5-49d1-8109-10bc4fdb07d3	\N	\N	85	PENDING	NAN-1774507803503-A16750E0	Pztrb2IIQIiwHartwJl7	2026-03-26 06:50:03.505	2026-03-26 06:50:03.879	raji_tawa@yahoo.com	Tawakaltu  Raji		GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
6b60269c-3f17-441f-a1e1-1619d1b28e36	\N	\N	85	PENDING	NAN-1774520471045-74980D41	lkfY7U2gSaucgirJsm23	2026-03-26 10:21:11.048	2026-03-26 10:21:11.492	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
b6484f82-18b4-44e7-95d8-4905dd3ff00b	\N	\N	85	PENDING	NAN-1774520585698-405373D0	moTjj1D0QJKeIRjJlZrl	2026-03-26 10:23:05.7	2026-03-26 10:23:06.004	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
e2a49db0-6fce-4f7b-94bd-16a1af5afe25	\N	mg_mcs	40000	PENDING	NAN-1774533653510-7FC56224	GQfgcFz6Rh2eEabLYQPq	2026-03-26 14:00:53.512	2026-03-26 14:00:53.988	pkailaivasan@gmail.com	Pavithra Kailaivasan	0710470769	LKR	https://nanaska.com	\N	\N
8c9fd7f5-cb07-4f47-8322-158be2dda529	\N	\N	85	FAILED	NAN-1774520820491-6C3D127C	1TBfT3yUTwGOYymnKYKS	2026-03-26 10:27:00.493	2026-03-26 10:28:43.195	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
ff82779a-9340-4cac-bd0f-0a0242e4184d	\N	\N	185	PAID	NAN-1774522746492-F4D4BEDA	CpS7EcBeTSqNGxo9MpAZ	2026-03-26 10:59:06.496	2026-03-26 11:36:50.934	michaelamoah100@gmail.com	Michael Amoah	+233248610969	GBP	https://nanaska.com	\N	2de7a7a6-8120-4ea2-9d51-d441eb211a30
4cd0c760-a29b-4313-95b2-0efe1e8d46fa	\N	st_scs	40000	PENDING	NAN-1774547771725-273E3124	T1FYfXivTiSoZtwQsBNU	2026-03-26 17:56:11.727	2026-03-26 17:56:12.056	bahee@dmsswe.com	Baheerathan Thillaiampalam	+94777224589	LKR	https://nanaska.com	\N	\N
e4f43ba5-d241-41c5-a9b9-023d12e327b9	\N	\N	85	PAID	NAN-1774527300024-DF411F4E	rEBGmt6ISrSITmbaOgHR	2026-03-26 12:15:00.026	2026-03-26 12:15:19.354	habibullah.lh46@gmail.com	Habib Lamin	+233558293278	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
835f1c9c-33e6-468c-b03c-b4697da45e55	\N	\N	85	FAILED	NAN-1774527066430-82FA0050	ADNn28fyQomLJw720dp8	2026-03-26 12:11:06.433	2026-03-26 12:17:35.927	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
85a9fd17-d873-4deb-8876-0d3a1aa3cfbb	\N	op_ocs	26650	PENDING	NAN-1774531193886-911D841C	k8Oyi09OS2Ki2OJqDKLg	2026-03-26 13:19:53.888	2026-03-26 13:19:54.264	akalanka@nanaska.com	Akalanka Ranasinghe	+94 77 584 4677	LKR	https://nanaska.com	\N	\N
e4d839d6-b697-43c9-98e1-6a5a97a009d2	\N	st_scs	40000	PENDING	NAN-1774548001542-9FB25D8C	xa59aCATTgKfELinS2Wd	2026-03-26 18:00:01.546	2026-03-26 18:00:01.998	bahee@dmsswe.com	Thillaiampalam   Baheerathan	+94777224589	LKR	https://nanaska.com	\N	\N
2930d026-8fab-4cc1-9153-10325cc5006e	\N	st_scs	40000	PENDING	NAN-1774548172759-B4AB7321	rmVZbUbjTiOC0mRZ83za	2026-03-26 18:02:52.761	2026-03-26 18:02:53.144	bahee@dmsswe.com	Baheerathan Thillaiampalam	0777224589	LKR	https://nanaska.com	\N	\N
0104979c-f014-4a47-81ff-6475779b4725	\N	mg_mcs	40000	PENDING	NAN-1774576340096-B0A0D723	U9hhdKoZTJSFIAQWifis	2026-03-27 01:52:20.1	2026-03-27 01:52:20.585	pkailaivasan@gmail.com	Pavithra Kailaivasan	0710470769	LKR	https://nanaska.com	\N	\N
af88567f-ad7b-45e3-972c-b1e4ae80fff1	\N	op_ocs	26650	PAID	NAN-1774579460789-3B1F75B0	xMdkWxVCTjOAMoCW2xf7	2026-03-27 02:44:20.791	2026-03-27 02:47:09.346	vindyavimukthini@gmail.com	Vindya Deshapriya	0701267642	LKR	https://nanaska.com	\N	\N
0aa60bc1-736c-421b-afea-12cf00db38ad	\N	\N	85	FAILED	NAN-1774593610367-4D908256	f1mQjmpxQryvMNfHhrYU	2026-03-27 06:40:10.37	2026-03-27 06:42:12.504	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	03068516-86c0-4970-97a7-c7a6b82203fa
c32bd470-82a6-4f83-afc4-1a7b06d3009d	\N	mg_mcs	40000	PENDING	NAN-1774599025484-52CBB275	Z3usdoOSTaCr1zdIqX6E	2026-03-27 08:10:25.487	2026-03-27 08:10:25.841	pkailaivasan@gmail.com	Pavithra Kailaivasan	0710470769	LKR	https://nanaska.com	\N	\N
607b3673-47f7-4762-b6d1-e369f0f8cd46	\N	cert_ba4	16000	PENDING	NAN-1774605063136-D6B77E00	twnC4aW1Q26zVUbg91Lp	2026-03-27 09:51:03.138	2026-03-27 09:51:03.451	akalanka@nanaska.com	Akalanka Ranasinghe	0775844677	LKR	https://nanaska.com	\N	\N
562bce53-fb33-4dc6-994c-cc57fc60a3ee	\N	st_scs	40000	PENDING	NAN-1774607222017-065AA2E7	qofzAqNDQWuJiLV7sRKT	2026-03-27 10:27:02.019	2026-03-27 10:27:02.659	wathsala@nanaska.com	H A Wathsala	0773669817	LKR	https://nanaska.com	\N	\N
07922508-28bb-4571-b79a-0c18b74b98ab	\N	\N	85	PENDING	NAN-1774610125499-30913C1A	DgatKirETHmv2CYgRIAb	2026-03-27 11:15:25.503	2026-03-27 11:15:25.831	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	03068516-86c0-4970-97a7-c7a6b82203fa
95415416-c3f8-4652-9611-cbe9936d2f7e	\N	\N	85	PENDING	NAN-1774610135582-4BB6AC63	lUOKyT2mRsyw2286u2Vj	2026-03-27 11:15:35.583	2026-03-27 11:15:35.802	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	03068516-86c0-4970-97a7-c7a6b82203fa
35efea69-6540-4004-9ec8-4464b297a64b	\N	\N	85	PAID	NAN-1774610336878-BA3EA731	g2kIexaXRKq1AitmTi5J	2026-03-27 11:18:56.88	2026-03-27 11:20:08.677	raji_tawa@yahoo.com	Tawakaltu  Raji	0242763834	GBP	https://nanaska.com	\N	03068516-86c0-4970-97a7-c7a6b82203fa
740b8aa3-9929-4d90-9900-4ab1fa960fa1	\N	\N	23985	PAID	NAN-1774674289320-B7F29C65	SmYe0usYShqGbF3LsdAa	2026-03-28 05:04:49.322	2026-03-28 05:06:41.67	chathuraathukorala1@gmail.com	Chathura  Athukorala	+94773813669	LKR	https://nanaska.com	\N	18829992-c579-4180-a6e2-fea530258e36
802debe6-fc74-4b10-a336-df3c7c183945	\N	\N	23985	PAID	NAN-1774612000142-1E144F3B	Q8vNN0PCTaC51medx8hw	2026-03-27 11:46:40.144	2026-03-27 11:48:27.762	r.a.n.samanthi@gmail.com	Niranjala  Samanthi	+94758004281	LKR	https://nanaska.com	\N	18829992-c579-4180-a6e2-fea530258e36
98ae2fe9-63ec-4e7e-a2b1-34337398b0bb	\N	st_scs	40000	PENDING	NAN-1774615694482-3552754A	csnu1mRaQXOmSUlvFg8P	2026-03-27 12:48:14.484	2026-03-27 12:48:14.782	wathsala@nanaska.com	Wathsala Gunawardana	0773669817	LKR	https://nanaska.com	\N	\N
4ea8e122-87b8-445e-97c8-3ab1252464b4	\N	st_scs	40000	PENDING	NAN-1774618190511-D04C2A38	UjMBXUcFSCmjZdMXCZYW	2026-03-27 13:29:50.512	2026-03-27 13:29:50.875	bahee@dmsswe.com	Baheerathan Thillaiampalam	0777224589	LKR	https://nanaska.com	\N	\N
d7b26c6e-07ce-40f9-bd17-1c7b5cdc4287	\N	mg_f2	175	PENDING	NAN-1774618740375-DF6448DC	IlunsfHmR8StVt3yFe8A	2026-03-27 13:39:00.377	2026-03-27 13:39:00.9	ryjomesy@mailinator.com	Kelly Suarez	+1 (961) 947-7672	GBP	https://nanaska.com	\N	\N
7cd902e9-98e7-4866-ae56-bd0f5d64e107	\N	st_scs	30750	PENDING	NAN-1774636412702-3AF5A7ED	pWtJ8m4mRT20uMWFy1iv	2026-03-27 18:33:32.704	2026-03-27 18:33:34.529	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
35dfd7dd-95fa-421e-82d4-bca09cc9935a	\N	\N	23985	PAID	NAN-1774666629102-F2216642	qqJcUnmPRZmFJZkTFVNY	2026-03-28 02:57:09.104	2026-03-28 02:58:19.981	ruvinidias96@gmail.com	Ruvini Dias	768502428	LKR	https://nanaska.com	\N	18829992-c579-4180-a6e2-fea530258e36
38bd2ef9-7c98-4d42-8274-1e8af8df383b	\N	mix_e1_e2	50000	PENDING	NAN-1774667346996-A4092AFA	JOQE0VYyTQaGRSZFwvDT	2026-03-28 03:09:06.997	2026-03-28 03:09:08.848	test@example.com	Test User	\N	LKR	https://nanaska.com	\N	\N
430a9745-c1cf-4b25-8f4e-8cf7dca030f2	\N	mix_mcs_scs	58425	PENDING	NAN-1774667867835-42D2F447	QEgz2f1vQ76rem51jvpp	2026-03-28 03:17:47.836	2026-03-28 03:17:48.273	lepugid@mailinator.com	Carlos Slater	+1 (463) 636-4359	LKR	https://nanaska.com	\N	\N
732d0213-6e7a-45a7-a3d2-86d3afc8cd84	\N	st_scs	30750	PENDING	NAN-1774685771979-DAE6EE1F	tlrf9zERQCOwStqL91fj	2026-03-28 08:16:11.986	2026-03-28 08:16:12.476	wathsala@nanaska.com	H A Wathsala	0773669817	LKR	https://nanaska.com	\N	\N
919af437-cd09-48f4-9833-9dcf53b5ec03	\N	op_ocs	26650	PAID	NAN-1774670125001-451F91BC	qRcnMjCbRmq2lhQi1yf8	2026-03-28 03:55:25.002	2026-03-28 03:56:54.581	nethmat16@gmail.com	Nethma Karunatilleke	0715473388	LKR	https://nanaska.com	\N	\N
a2842aed-661b-4077-9429-d35de923effb	\N	mg_mcs	27675	PENDING	NAN-1774690377836-44F14E19	RC3y5TnOSL2EJg32rXbE	2026-03-28 09:32:57.838	2026-03-28 09:32:58.147	vvds2006@gmail.com	Vinumi De Silva	0777031686	LKR	https://nanaska.com	\N	\N
31782764-3c87-441c-be08-89da3ed28fe7	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	204325	PENDING	NAN-1774697927527-A492601D	lTG1TzSMQR62i2JQO7yX	2026-03-28 11:38:47.528	2026-03-28 11:38:48.149	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
8b4b8d88-8d86-4a42-ace2-961ce1fd5fb7	\N	mg_mcs	27675	FAILED	NAN-1774690377900-00972246	HlTbB0pVS9ivq8Q7jihj	2026-03-28 09:32:57.901	2026-03-28 09:36:06.169	vvds2006@gmail.com	Vinumi De Silva	0777031686	LKR	https://nanaska.com	\N	\N
7b0cfdd4-f339-43ff-970e-7dee5cab242f	\N	mg_mcs	27675	PENDING	NAN-1774690613628-A7558676	fXmJLi11TR66rxJ73bE0	2026-03-28 09:36:53.629	2026-03-28 09:36:53.853	vvds2006@gmail.com	Vinumi De Silva	0777031686	LKR	https://nanaska.com	\N	\N
9145d9c5-6c26-45f8-8796-6003f3f58fe1	\N	mg_mcs	27675	PAID	NAN-1774695938140-FFF5B342	7xdCpmufQiWKfxOPix9G	2026-03-28 11:05:38.142	2026-03-28 11:07:59.864	shimlauvaim@gmail.com	Shimla Uvaim	0756695367	LKR	https://nanaska.com	\N	\N
b0beca4a-08c3-4674-b4b1-8ea0cf72f7f3	\N	mg_mcs	27675	PAID	NAN-1774690613643-B76111B1	lYYKKAHlSNSeTPXOQx2p	2026-03-28 09:36:53.645	2026-03-28 09:37:31.347	vvds2006@gmail.com	Vinumi De Silva	0777031686	LKR	https://nanaska.com	\N	\N
e40a9085-2421-40a3-9ad1-4321089135ca	\N	mg_mcs	27675	PAID	NAN-1774691727765-0F69C2D9	6Mo45BkBQl2ZHlxJzXUN	2026-03-28 09:55:27.766	2026-03-28 09:57:58.794	chandinep1@gmail.com	Chandima  Senevirathne 	0714346356	LKR	https://nanaska.com	\N	\N
31a74415-d6a7-4f27-ae7c-d73979faf4f8	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	204325	PENDING	NAN-1774697816668-963A5DBF	4vbqPBkUQNCe6upmFioy	2026-03-28 11:36:56.671	2026-03-28 11:36:56.949	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
8b58e221-3a75-4668-8d9c-6e0c9d426415	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	204325	PENDING	NAN-1774697875665-C13B94D6	m253EOY7RXebh99S61kR	2026-03-28 11:37:55.667	2026-03-28 11:37:55.905	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
b5a376d3-c1e1-407a-9977-33b679344315	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	204325	PENDING	NAN-1774697875798-05E29875	Zp6Amt9ZQVug0tB0gVGx	2026-03-28 11:37:55.799	2026-03-28 11:37:56.007	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
869da0d8-963f-4e12-9764-6936509061ba	\N	op_full	75000	PENDING	NAN-1774697998861-04D183C9	W9NS94oHTsalwq5IrctM	2026-03-28 11:39:58.863	2026-03-28 11:39:59.125	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
305495c5-0836-4905-9087-f184615d1d5d	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	204325	PENDING	NAN-1774698049216-B5A15D88	FX31fqxlTqazl2fmDAWL	2026-03-28 11:40:49.218	2026-03-28 11:40:49.544	channa@nanaska.com	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
a044a36c-56f0-4634-a31a-f4796fa9a33c	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	1948	PENDING	NAN-1774698064861-D886D9B7	x77UWeDMS5KMTGW82Obi	2026-03-28 11:41:04.863	2026-03-28 11:41:05.128	jukaqexoh@mailinator.com	Shelby Witt	+1 (633) 276-6086	GBP	https://nanaska.com	\N	\N
27bc529e-b80c-4d6b-8b94-43d85ddd3f57	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	1200	PENDING	NAN-1774698831020-FCC619E0	y40PBsuBQNqK1FPdNl2Y	2026-03-28 11:53:51.022	2026-03-28 11:53:51.356	admin@theredsun.org	Miyuru Dharmage	077 439 5913	GBP	https://nanaska.com	\N	\N
085388a5-f5fd-4381-b3c0-2012b8af689a	\N	mix_e1_e2_f1_f2_mcs_ocs_p1_p2	152775	PENDING	NAN-1774698920948-303B4CBD	YyHh2BcITmSjR15xa0NP	2026-03-28 11:55:20.95	2026-03-28 11:55:21.213	admin@theredsun.org	Miyuru Dharmage	077 439 5913	LKR	https://nanaska.com	\N	\N
bf13d43d-4540-4588-be47-0bdfb49ab513	\N	\N	22500	FAILED	NAN-1774772598556-4750549D	KK0j0G4yToiN5zSQpb1T	2026-03-29 08:23:18.559	2026-03-29 08:27:09.095	chamiprabath2003@gmail.com	chaminda Marasinghe	+94771052926	LKR	https://nanaska.com	\N	7e54d03a-7e71-4309-9e93-9015f12cdd25
f47b9171-b7f2-419d-a256-67e5705efa17	\N	\N	22500	PENDING	NAN-1774774803627-886601E0	qNC3bRqOT22M5Y1c92YR	2026-03-29 09:00:03.629	2026-03-29 09:00:03.99	chamiprabath2003@gmail.com	Chaminda Marasinghe	771052926	LKR	https://nanaska.com	\N	7e54d03a-7e71-4309-9e93-9015f12cdd25
6fa789f1-ff45-40e2-b771-b4611ab64bd5	\N	\N	22500	PAID	NAN-1774776064510-B11E0245	rCsIMtI5TJe0nq0Bk5nl	2026-03-29 09:21:04.512	2026-03-29 09:26:19.596	olandeananda@gmail.com	Rudolf Hammelburg	+94773508384	LKR	https://nanaska.com	\N	7e54d03a-7e71-4309-9e93-9015f12cdd25
a0dea07b-5119-4ce2-8aa8-e2f14538929f	\N	\N	185	PAID	NAN-1774810811000-8F866757	eHpaTkjpRGKxr1VQ2BPC	2026-03-29 19:00:11.003	2026-03-29 19:04:22.669	jchaonsa6@gmail.com	JOSEPH CHAONSA	+260977788661	GBP	https://nanaska.com	\N	f12cfc0a-1cd2-493a-84d1-1264b417d4bf
40e9ce27-213f-404d-aa27-1c53bd71659d	\N	\N	23985	PAID	NAN-1774857155505-04E56302	esDHcC0RTDSXMN9t23oq	2026-03-30 07:52:35.507	2026-03-30 07:56:41.338	anus36642@gmail.com	Anuththara Sewmini	+94777289832	LKR	https://nanaska.com	\N	18829992-c579-4180-a6e2-fea530258e36
2faa55bd-d9cd-4835-9d64-d3ca79ec4a44	\N	\N	85	PENDING	NAN-1774863242575-28264C46	m2UfTJcLR9a3lMb44OGe	2026-03-30 09:34:02.578	2026-03-30 09:34:03.296	lisaboatengk@gmail.com	Lisa Boateng 	+233201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
84d2782e-9caf-4e5f-b32a-305ff8c8e244	\N	\N	85	PENDING	NAN-1774899050362-8D269174	\N	2026-03-30 19:30:50.365	2026-03-30 19:30:50.365	lisaboatengk@gmail.com	Lisa Boateng	+233201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
b84fd001-262e-487f-82fe-9e45b156ec48	\N	\N	85	PENDING	NAN-1774899177315-2A36F368	\N	2026-03-30 19:32:57.317	2026-03-30 19:32:57.317	lisaboatengk@gmail.com	Lisa Boateng	+233201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
4cbc2a12-b90e-43dc-9732-25c8d8379815	\N	\N	85	PENDING	NAN-1774899364116-5BA292EF	\N	2026-03-30 19:36:04.119	2026-03-30 19:36:04.119	lisaboatengk@gmail.com	Lisa  Boateng	+233 201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
527d3d10-8a71-4061-863d-5b8e749088bd	\N	\N	85	PENDING	NAN-1774899510399-1E9A9DBD	\N	2026-03-30 19:38:30.401	2026-03-30 19:38:30.401	lisaboatengk@gmail.com	Lisa  Boateng	+233 201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
a51aabb1-813f-458c-beec-b1add72cdadf	\N	\N	85	PENDING	NAN-1774903371134-C6386825	\N	2026-03-30 20:42:51.136	2026-03-30 20:42:51.136	lisaboatengk@gmail.com	Lisa  Boateng	+233 201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
39b258d2-b36b-4f83-9f0e-194b3f091083	\N	\N	85	PENDING	NAN-1774903407360-C5C7EF71	\N	2026-03-30 20:43:27.362	2026-03-30 20:43:27.362	lisaboatengk@gmail.com	Lisa  Boateng	+233 201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
ac8b57bd-63fb-44fe-a3de-7757a745e7a2	\N	\N	85	PENDING	NAN-1774904041098-37CFA0CE	\N	2026-03-30 20:54:01.099	2026-03-30 20:54:01.099	lisaboatengk@gmail.com	Lisa  Boateng 	+233201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
8b4e5475-5b95-479d-8a59-ee123b9c7b3a	\N	\N	85	PENDING	NAN-1774904057253-26828412	\N	2026-03-30 20:54:17.254	2026-03-30 20:54:17.254	lisaboatengk@gmail.com	Lisa  Boateng 	+233201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
c3800213-b34a-46a6-b6e6-5f1f977aeb21	\N	\N	85	PENDING	NAN-1774904106160-FC207891	\N	2026-03-30 20:55:06.162	2026-03-30 20:55:06.162	lisaboatengk@gmail.com	Lisa  Boateng 	+233201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
de1aaa31-d65a-4518-8be6-3b71ee2d471c	\N	\N	85	PENDING	NAN-1774909826475-ECB58675	\N	2026-03-30 22:30:26.477	2026-03-30 22:30:26.477	lisaboatengk@gmail.com	Lisa  Boateng	+233 201197705	GBP	https://nanaska.com	\N	5b9300ef-845f-47d6-b4aa-4e7f576ef2c8
\.


--
-- Data for Name: page_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_meta (id, page_path, page_title, meta_title, meta_desc, meta_keywords, og_title, og_desc, og_image, created_at, updated_at) FROM stdin;
887fbf90-f123-45e8-b1fe-66c9dd029a6a	/	Home	Nanaska						2026-03-24 14:09:19.654	2026-03-24 14:09:19.654
\.


--
-- Data for Name: payment_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_links (id, slug, label, student_name, student_email, amount, currency, description, password_hash, expires_at, expire_on_payment, is_active, is_paid, paid_at, created_by_admin_id, created_at, updated_at) FROM stdin;
d6814f94-613c-46d9-b226-318f981ac185	2i77vr17i1sw	Adipisci autem exped	Ralph Vasquez	waworyc@mailinator.com	90	GBP	Sed magna asperiores	\N	\N	f	t	f	\N	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 09:29:13.398	2026-03-25 09:29:13.398
39015f52-ff27-46e3-a208-310b2db4047c	367omyafomdc	OCS - F	General Student	info@nanaska.com	185	GBP	OCS May 2026 Intake 	\N	\N	f	t	f	\N	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 12:58:09.613	2026-03-25 12:58:09.613
2f0275c7-227e-4a2a-af0c-9177e0556375	q38w4d4kzr3k	MCS - Re Sit SL	General Student	wathsala@nanaska.com	24907	LKR	MCS Re Sit Student Fee	\N	\N	f	t	f	\N	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:03:30.1	2026-03-25 13:03:30.1
a18fa9f1-f600-4a87-91bf-accf89fbbf5f	nacu55bip978	MCS - F	General Student	wathsala@nanaska.com	250	GBP	MCS Course Fee 50% Discounted	\N	\N	f	t	f	\N	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:05:47.669	2026-03-25 13:05:47.669
8ccaec6b-3f81-4d2c-a8d3-d29a07668676	1wdi9bcrjip4	SCS - Re sit SL	General Student	wathsala@nanaska.com	27675	LKR	SCS Re Sit Student Fee - SL	\N	\N	f	t	f	\N	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:11:05.883	2026-03-25 13:11:05.883
bee52c21-7dc7-4c3c-a80c-fe96c1ba68dc	0yrz0xewxhls	SCS - F	General Student	wathsala@nanaska.com	300	GBP	SCS Course Fee 50% Discounted	\N	\N	f	t	f	\N	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:13:45.227	2026-03-25 13:13:45.227
a2ffbc7a-67d7-4420-83c2-f850b770d521	aetddlole8hj	Case Study - Re sit GBP	General Student	wathsala@nanaska.com	185	GBP	Case Study Re sit Fee - GBP	\N	\N	f	t	t	2026-03-26 06:37:15.966	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:23:44.574	2026-03-26 06:37:15.97
2de7a7a6-8120-4ea2-9d51-d441eb211a30	br6jk1wstr5f	MCS - Ghana	General Student	wathsala@nanaska.com	185	GBP	MCS Ghana Course Fee	\N	\N	f	t	t	2026-03-26 11:36:50.946	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:06:41.663	2026-03-26 11:36:50.947
5b9300ef-845f-47d6-b4aa-4e7f576ef2c8	74ol7yfb3mxl	OCS - Ghana	General Student	wathsala@nanaska.com	85	GBP	OCS Ghana Special Course	\N	\N	f	t	t	2026-03-26 12:15:19.36	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 12:59:50.823	2026-03-26 12:15:19.361
03068516-86c0-4970-97a7-c7a6b82203fa	23qem8kbcvqb	OCS - Ghana 2	\N	\N	85	GBP	OCS Ghana Student Fee	\N	\N	f	t	t	2026-03-27 11:20:08.684	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-27 06:33:51.033	2026-03-27 11:20:08.685
7e54d03a-7e71-4309-9e93-9015f12cdd25	sqqfi1rbax4c	OCS Re sit	Chaminda Prabath	chamiprabath2003@gmail.com	22500	LKR	OCS Re sit Feb 2026	\N	\N	f	t	t	2026-03-29 09:26:19.602	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-29 08:12:27.713	2026-03-29 09:26:19.603
f12cfc0a-1cd2-493a-84d1-1264b417d4bf	731h2st0bgpb	SCS - Ghana	General Student	wathsala@nanaska.com	185	GBP	SCS Ghana Course Fee	\N	\N	f	t	t	2026-03-29 19:04:22.676	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:15:22.297	2026-03-29 19:04:22.677
18829992-c579-4180-a6e2-fea530258e36	pfenvwdbs7z0	OCS - Re sit SL	General Student	wathsala@nanaska.com	23985	LKR	OCS Re Sit Student Rate 	\N	\N	f	t	t	2026-03-30 07:56:41.348	948881ac-ce8b-4436-ad98-4ebfa0140572	2026-03-25 13:01:18.658	2026-03-30 07:56:41.349
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, key, value, category, label, created_at, updated_at) FROM stdin;
568494b9-8bef-42ea-98e8-43ea119c9ed7	reminder_max_months		email	Stop Reminders After (months)	2026-03-27 10:25:01.357	2026-03-27 12:46:10.022
a3e50d0d-55d2-43ac-a6d4-a18a4509bf71	email_webhook_auth_value	QWZ^*(hoi8X88":T{#_1R%%V^',<,\\.FMAqzeo£;	email	Auth Header Value	2026-03-24 14:05:22.354	2026-03-27 12:46:10.021
f7fe49a0-55d1-4d73-916a-bb8464a5aedb	email_from_name	Nanaska	email	From Name	2026-03-24 14:05:22.354	2026-03-27 12:46:10.021
caaa16bd-0773-40a6-b9e5-57aac20eb2ab	email_cc	info@nanaska.com	email	CC – General Emails	2026-03-24 14:05:22.354	2026-03-27 12:46:10.021
89038bc6-f40f-4760-bab5-ec7eb32e75c4	email_webhook_auth_key	monthra	email	Auth Header Name	2026-03-24 14:05:22.355	2026-03-27 12:46:10.021
e2bf5a5b-3172-43fa-9f95-0e7e72efe72c	google_analytics_id		analytics	Google Analytics Measurement ID	2026-03-20 08:07:10.004	2026-03-27 14:35:43.522
f03beeb9-381d-41e9-bc71-cb9b1bb9aa7b	meta_pixel_id		analytics	Meta Pixel ID	2026-03-20 08:07:10.01	2026-03-27 14:35:43.537
1259ed29-d8f0-4120-a2a0-f0ce61f7aa58	payment_gateway_client_id		payment	Payment Gateway Client ID	2026-03-20 08:07:10.014	2026-03-27 14:35:43.543
668fff2d-f5a1-4c8d-962e-17ccc16a991c	payment_gateway_secret		payment	Payment Gateway Secret	2026-03-20 08:07:10.018	2026-03-27 14:35:43.548
4ed71a33-f3de-4433-b8e5-9e0a60d5c70a	payment_success_url	/payment-success	payment	Payment Success URL	2026-03-20 08:07:10.022	2026-03-27 14:35:43.553
beb044f6-e4a4-4957-8bac-42eab723857f	payment_cancel_url	/payment-cancel	payment	Payment Cancel URL	2026-03-20 08:07:10.028	2026-03-27 14:35:43.558
d40ee59f-51f1-43e5-b561-344ce4c60037	site_name	Nanaska	general	Site Name	2026-03-20 08:07:10.033	2026-03-27 14:35:43.563
0e2f264a-3b2f-4280-9c0e-a33e109e139c	s3_bucket_url		storage	S3 Bucket URL	2026-03-20 08:07:10.037	2026-03-27 14:35:43.57
d311357a-2252-402b-8464-767fbb31ca72	sse_endpoint		sse	SSE Events Endpoint	2026-03-20 08:07:10.044	2026-03-27 14:35:43.574
eee1bda3-7d94-414e-9b44-ec3489436334	email_webhook_url	https://automation.nanaska.com/webhook/send-email	email	Webhook URL	2026-03-24 14:05:22.353	2026-03-27 12:46:10.021
85743a62-9b68-4e85-a0c1-054475f143b8	reminder_intervals	1,3,4,8	email	Reminder Intervals (days)	2026-03-27 10:25:01.357	2026-03-27 12:46:10.021
920435fc-0ac8-47a3-bec1-73e05b19847d	email_payment_cc	finance@nanaska.com,info@nanaska.com	email	CC – Payments & Enrolments	2026-03-27 10:25:01.357	2026-03-27 12:46:10.021
29ffb3f2-6a1a-45b6-9a12-ba7536949edd	ipg_gbp_client_id	14004406	payment	IPG GBP Client ID	2026-03-20 08:07:10.049	2026-03-27 14:35:43.582
c4ea267a-f42d-4a59-90c0-12587ad5e237	ipg_lkr_client_id	14004606	payment	IPG LKR Client ID	2026-03-20 08:07:10.054	2026-03-27 14:35:43.588
66b26d5b-56e7-42f5-a18b-1a0b9275d457	contact_phones	["+94 77 499 7338","+94 77 711 8902","+94 112 575 016"]	contact	Contact Phone Numbers (JSON array)	2026-03-20 08:07:10.057	2026-03-27 14:35:43.594
a56f9333-0028-4811-991c-4ce20aaeaad4	contact_email	info@nanaska.com	contact	Contact Email	2026-03-20 08:07:10.061	2026-03-27 14:35:43.601
a735f7bf-7ab5-4c21-b10e-8f85aeb9599c	contact_address	No. 464/1/1, Galle Road, Colombo 03, Sri Lanka	contact	Office Address	2026-03-20 08:07:10.064	2026-03-27 14:35:43.607
cfe164fc-3a22-42df-b3fb-a122a238624d	contact_map_lat	6.8955	contact	Map Latitude	2026-03-20 08:07:10.067	2026-03-27 14:35:43.613
5291aa2f-e598-4200-aacd-d1790f938bfa	contact_map_lng	79.8527	contact	Map Longitude	2026-03-20 08:07:10.069	2026-03-27 14:35:43.619
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, student_name, country, flag, tag, exam, period, year, marks, image_url, quote, video_url, badge, is_prize_winner, published, sort_order, created_at, updated_at) FROM stdin;
0ce2e546-38fe-44c9-84ab-321d1b09e5be	Ammar Ilyas	Sri Lanka	🇱🇰	SCS	Strategic Case Study	May 2024	2024	99	/images/2024-10-ammar-scs-copy.jpg	Nanaska is unique because it offers an "all-you-need" source to pass your CIMA exams on the first attempt. The lecturers are well-versed with the reality of the exams and practice what they teach in their daily lives. All you need to do is to do exactly as the lecturers say!	\N	\N	f	t	2	2026-03-20 08:10:52.972	2026-03-29 03:13:08.165
a5ef5d2c-a719-4dd8-b988-fd79d353789f	Salaama Sanoon	Sri Lanka	🇱🇰	OCS	Operational Case Study	May 2024	2024	108	/images/2024-10-Salaama-OCS-copy.jpg	I would like to sincerely thank the entire team including the lecturers and the staff at Nanaska for their unwavering support and commitment in helping me pass my OCS exam with confidence. The refresh theory sessions conducted by the lecturers and the mocks given were extremely helpful as they covered every possible area that could be tested in the exam. The one on one attention that was given to us after completing our mocks helped me to correct my mistakes and improve.	\N	\N	f	t	9	2026-03-20 08:10:53.018	2026-03-29 03:13:08.172
e24aa932-a64f-4915-9795-985db2f32360	Fuseini Awiagah	Ghana	🇬🇭	SCS	Strategic Case Study	Aug 2024	2024	80	/images/2024-10-WhatsApp-Image-2024-10-13-at-15.03.21_43435e43.jpg	Mr. Channa and Mr. Ali Raheem from the Nanaska team are by far the best tutors for CIMA SCS. Their ability to breakdown theories and invoke students' critical thinking abilities is remarkable. Their exceptional support along with study materials such as power mock made the learning process much easier than I had anticipated. I owe my pass mark to Nanaska.	\N	\N	f	t	1	2026-03-20 08:10:52.966	2026-03-29 03:13:08.179
4d350b97-3bb4-45ec-bffa-35c2191c06ca	Sandun Ediriweera	Sri Lanka	🇱🇰	SCS	Strategic Case Study	May 2024	2024	90	/images/2024-10-Sandun-SCS-copy.jpg	I am grateful for NANASKA and its exceptional lecturers, especially Channa Sir, for helping me successfully complete the strategic level case study. The program's strengths are effective answering techniques, in-depth business analysis, realistic mock exams, comprehensive theory refreshers, one-to-one mentoring, lecturers' expertise, and high-quality mock papers, which were key to my success. I highly recommend NANASKA for anyone aiming to excel in their strategic level case study.	\N	\N	f	t	3	2026-03-20 08:10:52.979	2026-03-29 03:13:08.186
97bf1857-bd96-4ce0-aeae-85710d65d7c0	Suheelan Ramanathan	Malaysia	🇲🇾	SCS	Strategic Case Study	May 2024	2024	83	/images/2024-10-Suheelan-scs-copy.png	I am glad to be part of Nanaska. The lecturers were incredibly knowledgeable and supportive, guiding me through every step of my learning journey. The learning approach allowed me to improve my business acumen skills and helped me to think in a strategic perspective when planning long term business goals. I used the case study materials extensively, and found the pre-seen analysis and mock exams were solid preparation for the actual exams. I felt prepared and confident that I had a full grasp of the scenarios and could deliver strong answers to the questions. Special thanks to Mr. Chana Gunawardana and Mr. Ali Raheem for helping to make this long time dream a reality.	\N	\N	f	t	4	2026-03-20 08:10:52.985	2026-03-29 03:13:08.191
02135cdf-4d24-4a8c-86d2-9c7600c5cbef	Chamod Deshitha	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	92	/images/2024-10-Chamod-MCS-copy.jpg	A colleague's recommendation led me to Mr. Channa Gunawardana's CIMA Management Case Study classes at Nanaska. Even though most classes were online, the classes were very engaging and enjoyable, replicating the energy of a physical classroom. I was able to pass the Management Level Case Study on my first attempt. Mr. Channa's guidance and the support of the Nanaska Team played a vital role in my success. I highly recommend Nanaska for anyone who is preparing for their CIMA exams.	\N	\N	f	t	6	2026-03-20 08:10:52.998	2026-03-29 03:13:08.203
779df991-c2df-449d-86b0-a4e713f4e3c3	Isuru Perera	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	110	/images/2024-10-Isuru-MCS-copy.jpg	I want to express my heartfelt gratitude to Mr. Channa Gunawardhana and the entire Nanaska team for their invaluable support in helping me pass the management case study. Without their guidance, this would have been a daunting challenge. Their mentorship showed me the path to success in tackling the management case study. Additionally, the study materials provided by Nanaska, including the mock exams and resources like KYP, KYI, and power mocks, played a crucial role in eliminating my exam anxieties and preparing me thoroughly for the final assessment.	\N	\N	f	t	7	2026-03-20 08:10:53.003	2026-03-29 03:13:08.216
8e5da48d-2275-4cb2-b5a3-0bce84df0e4f	Shalika Nilmini	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	85	/images/2024-10-Shalika-MCS-copy.jpg	I am thrilled to share my experience of successfully completing the CIMA Management Case Study under the guidance of Channa Sir and his exceptional team at Nanaska. The journey was challenging yet immensely rewarding, and I owe much of my success to their unwavering support and expertise. From the very beginning, Channa Sir and his team provided comprehensive study materials, insightful lectures, and personalized feedback that were instrumental in my preparation. Their deep understanding of the CIMA curriculum and practical business scenarios helped me bridge the gap between theory and real-world application.	\N	\N	f	t	8	2026-03-20 08:10:53.01	2026-03-29 03:13:08.221
a02154e6-2ae2-4d19-818a-3afa5ea7ba9c	Supipi Kandegedara	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	86	/images/2024-10-beautiful-blonde-woman-with-makeup-avatar-for-a-beauty-salon-illustration-in-the-cartoon-style-vector.jpg	I am happy to share my experience with Nanaska, which played a pivotal role in my success in the MCS exams. From the moment I enrolled, I was impressed by the comprehensive and well-structured curriculum designed to cover all aspects of the MCS syllabus. The interactive classes, combined with practical case studies and real-world examples, helped me grasp complex concepts with ease. Additionally, the regular mock tests and feedback sessions were invaluable in identifying my strengths and areas for improvement, allowing me to focus my efforts effectively. Thanks to Nanaska and Channa sir I not only passed my MCS exams with good marks but also gained a deeper understanding and appreciation of the subjects. I wholeheartedly recommend Nanaska to anyone seeking to excel in their CIMA exams.	\N	\N	f	t	11	2026-03-20 08:10:53.035	2026-03-29 03:13:08.238
ac4554c1-fc03-4297-8c3f-5129628d66dc	Pujani Sanjeewani	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	90	/images/2024-10-Pujani-MCS-copy.jpg	I am immensely grateful to Nanaska for their exceptional support and guidance in helping me pass the CIMA Management case study exam with higher marks. The expertise and dedication of Mr. Channa Gunawardana and the team played a crucial role in my success. Their tailored approach and constant encouragement were invaluable. They went above and beyond to ensure I was well-prepared, providing me with the confidence and knowledge needed to excel. I highly recommend Nanaska to anyone seeking top-notch tutoring for CIMA. Their support truly makes a difference!	\N	\N	f	t	12	2026-03-20 08:10:53.042	2026-03-29 03:13:08.243
a19721fc-9f76-4dbb-8d84-affa524c49a7	Hiruni Hewage	Sri Lanka	🇱🇰	OCS	Operational Case Study	May 2024	2024	94	/images/2024-10-Untitled-2-9.jpg	I would like to extend my heartfelt gratitude to the Nanaska team for their invaluable support in helping me complete my OCS exam. The well-structured mock exams and personalized feedback helped me identify and improve upon my weak areas, making me more confident and well-prepared for the exam. I am truly thankful for the dedication and commitment of the entire team, and I highly recommend Nanaska Institute to anyone seeking academic excellence.	\N	\N	f	t	13	2026-03-20 08:10:53.048	2026-03-29 03:13:08.248
5b80fc16-a3a1-4040-a2f5-c7af11cc3b17	Imalsha Hikkaduwage	Sri Lanka	🇱🇰	OCS	Operational Case Study	May 2024	2024	103	/images/2024-10-Imalsha-ocs-copy.jpg	Having done self-studies for all my prior OTQs I had no idea as to what the case study would hold and how to apply my knowledge to the case study examination. So with just one and a half months to go for my OCS I came across Nanaska. The mock papers that were given by Nanaska and the personalized feedback given on each paper not only boosted my confidence but also made the exam a breeze.	\N	\N	f	t	14	2026-03-20 08:10:53.053	2026-03-29 03:13:08.253
76bab8ec-bb00-4720-b626-666b2abcb943	Sanuda Minuraka	Sri Lanka	🇱🇰	SCS	Strategic Case Study	Feb 2024	2024	99	/images/2024-10-Untitled-2-7.jpg	Appreciate all the guidance & support given by Channa sir and Nanaska Team to make my FLP journey a success and being able to finish off my CIMA journey in six months. The unwavering support by Team Nanaska carried me a long way by giving me a holistic exposure in my CIMA journey, all my gratitude and respect goes towards Channa sir & Nanaska.	\N	\N	f	t	15	2026-03-20 08:10:53.06	2026-03-29 03:13:08.257
a8bf094e-d269-44dd-a45a-d580b783da13	Upeshika Chathurangee	Sri Lanka	🇱🇰	SCS	Strategic Case Study	Feb 2024	2024	83	/images/2024-10-Untitled-2-6.jpg	It was an amazing journey of becoming a CIMA CGMA passed finalist with Nanaska. Thanks to Channa sir, Mark sir, Ali sir and Nanaska team, I was able to get through all three examinations with first attempt. I specially would like to mention about their mock papers and one to one sessions. Those things were very helpful to all of my success. One on one guidance and results focused interaction really helped me to get through CIMA FLP. My heartiest wishes to Channa sir and Nanaska team!	\N	\N	f	t	16	2026-03-20 08:10:53.067	2026-03-29 03:13:08.263
94e09c4f-bebb-4b62-929a-eb3e0c40b401	Chanuli Wijesinghe	Sri Lanka	🇱🇰	SCS	Strategic Case Study	Feb 2024	2024	80	/images/2024-10-Untitled-2-5.jpg	During my CIMA journey, working with Nanaska was a true game-changer. Their persistent support, knowledgeable advice, and in-depth understanding of the subject matter were invaluable. I not only passed my CIMA tests but also became a more competent and knowledgeable professional as a result of Channa sir's teachings. I wholeheartedly recommend Nanaska to anyone seeking excellence in their CIMA journey.	\N	\N	f	t	17	2026-03-20 08:10:53.074	2026-03-29 03:13:08.268
9d77a55e-37b9-4371-8ca8-d9c1b3c59e1d	Lochan Kuruwita	Sri Lanka	🇱🇰	OCS	Operational Case Study	Feb 2024	2024	92	/images/2024-10-Untitled-2-8.jpg	Nanaska have a great support system which is flexible and practical that we can do studies with our own pace! I'll recommend Nanaska to anyone who wishes to pursue CIMA through FLP!	\N	\N	f	t	18	2026-03-20 08:10:53.079	2026-03-29 03:13:08.272
9d0d8eb0-97ed-4b21-afbb-62e18dfc44c5	Emomotimi Agama	Nigeria	🇳🇬	SCS	Strategic Case Study	May 2017	2017	\N	/images/2021-06-Agama.png	Thanks to Nanaska for the plan put in place to ensure my success. The level of personal involvement of the facilitator and the constant nudging provided me with a great deal of materials that helped me achieve my goal. The emphasis on particular areas is very important and any student that desires to pass must take these points seriously. There is no option to starting early in your preparation as this will enable you cover all the areas you are expected to cover and give room for strategic revision. Will recommend Nanaska to anyone, any day and anytime.	\N	\N	f	t	50	2026-03-20 08:10:53.296	2026-03-29 03:13:08.276
03f5985f-a693-4f50-960b-3e0eaa0fd10a	Shernaya Morel	Sri Lanka	🇱🇰	OCS	Operational Case Study	Nov 2023	2023	112	/images/2024-10-OCS-Shernaya-Senorine-Morel-1.jpg	Nanaska Institute truly provided invaluable support and guidance in my preparation for the OCS exam. The lecturers' unwavering efforts from excellent study materials to personalized attention helped me gain a better understanding of the material. I wholeheartedly recommend Nanaska Institute for anyone aspiring to excel in their pursuit of CIMA certification.	\N	\N	f	t	21	2026-03-20 08:10:53.097	2026-03-29 03:13:08.285
47e8f88c-fc80-4164-9aa1-854149dae323	Udula Subodha	Sri Lanka	🇱🇰	SCS	Strategic Case Study	Nov 2023	2023	81	/images/2025-08-Udula-Subodha-e1754311089359.jpg	I would like to really thank you for the Channa sir as well as other two lecturers for their highest support throughout this period. Without your support, I would not be able to complete this final case study examination. Again thank you so much academic and Non academic staff who were dedicated on behalf of our students to enhance their knowledge and skills to finish this CIMA Examinations. Channa sir, the consent you delivered for us "Fight, Fight, Fight, until the last minute, Last second. Do not give up", really helped me to pass the exam.	\N	\N	f	t	22	2026-03-20 08:10:53.102	2026-03-29 03:13:08.289
f76a21ba-1d67-45cb-aa7a-19ba2822cffa	Dimitra Perera	Sri Lanka	🇱🇰	SCS	Strategic Case Study	Nov 2023	2023	84	/images/2024-10-SCS-G.S.Dimitra-Perera.jpg	I joined Nanaska Institute midway through their November Strategic Case Study lectures. In three weeks, Mr. Channa Gunawardana and the lecture panel was able to prepare me with the necessary skills, knowledge, competencies and industry specific knowledge required to successfully pass the exam. I would like to sincerely thank everyone at Nanaska for coaching me in those three short weeks and helping me pass on my very first attempt.	\N	\N	f	t	23	2026-03-20 08:10:53.108	2026-03-29 03:13:08.295
3953408b-7fa8-4330-a4f6-f002e7aa7326	Mehara Jayalath	Sri Lanka	🇱🇰	SCS	Strategic Case Study	Nov 2023	2023	86	/images/2024-10-SCS-Mehara-Jayalath.jpg	The knowledge and support given from Nanaska made me face the exam with confidence. This journey not just helped me pass the SCS exam but also trained me to solve real life corporate problems. I am forever grateful for Mr Channa for the motivation, exam techniques and for his unique teaching methods.	\N	A Star Program	f	t	24	2026-03-20 08:10:53.115	2026-03-29 03:13:08.301
64fc3796-50c4-4070-9eb3-91d69cc46ade	Menaka Jesudasan	Sri Lanka	🇱🇰	OCS	Operational Case Study	Nov 2023	2023	97	/images/2024-10-OCS-Menaka-Jesudasan-1.jpg	I'm Menaka Niroshani who has done my OCS Nov 23 with Nanaska… I must say that it was an incredible journey and I cleared my OCS today. My heartfelt thanks goes to the OCS lecturer Mr. Mark and Mr. Osmand who supported throughout the journey and the whole Nanaska team. Wishing Nanaska team all the best for the future.	\N	\N	f	t	25	2026-03-20 08:10:53.122	2026-03-29 03:13:08.305
5985e67f-999d-4ec1-8498-86504a4b0fc0	Nethmi Kosmullage	Sri Lanka	🇱🇰	MCS	Management Case Study	Nov 2023	2023	86	/images/2024-10-IMG_1256.jpg	When it comes to MCS, Channa sir's teaching style helped me a lot to get through the exam without studying theory areas in depth and it's like a miracle to me. So I'm forever grateful for choosing Nanaska as the tuition provider for my CIMA journey.	\N	\N	f	t	26	2026-03-20 08:10:53.127	2026-03-29 03:13:08.311
c0b92a40-8f7d-4bc1-a58c-aa62076691f6	Pawani Perera	Sri Lanka	🇱🇰	OCS	Operational Case Study	Nov 2023	2023	90	/images/2024-10-Untitled-2-4.jpg	I wanted to express my sincere gratitude for Nanaska for the support throughout the CIMA Operational Case Study. The guidance and expertise played a pivotal role in my success, and I am truly thankful for the teaching and commitment to my success.	\N	\N	f	t	27	2026-03-20 08:10:53.136	2026-03-29 03:13:08.315
b34fb8d3-382f-4a95-ac36-e4b284125891	Kolinda Lasantha	New Zealand	🇳🇿	OCS	Operational Case Study	Aug 2023	2023	\N	/images/2024-10-412064022_389492800121908_8493321068356738755_n.jpg	When I joined Nanaska, passing the OCS exam was just a dream, but Nanaska helped me achieve it. The lecturers provided excellent support through online classes, mock exams, and high-quality study materials. I am especially grateful to Mr. Mark Gunathilaka and Mr. Osmand Fernando for helping me achieve my goal of becoming CIMA certified while working full-time as an accountant. I highly recommend Nanaska Institute to anyone considering pursuing CIMA certification.	\N	\N	f	t	28	2026-03-20 08:10:53.143	2026-03-29 03:13:08.319
9fab37a9-8000-46dd-bd88-75409208b49d	Piyumi Divyanjali	Sri Lanka	🇱🇰	SCS	Strategic Case Study	May 2023	2023	103	/images/2024-10-Untitled-2.jpg	I appreciate the enormous support offered by Nanaska team for me to pass the Strategic Level case study with a good score. I completed my OTQ exams two years ago and was doubtful about my chances of passing the SCS exam without a clear memory of the subjects. Nonetheless, the holistic approach followed by Channa Sir and staff while giving personal attention to each student was very helpful and it was one of the fundamental reasons behind my success. I am really grateful for Nanaska team for all the efforts behind these achievements.	\N	\N	f	t	29	2026-03-20 08:10:53.153	2026-03-29 03:13:08.323
2394190e-5075-41d1-bb5b-be25d4e892b9	Fathima Shifara	Sri Lanka	🇱🇰	OCS	Operational Case Study	May 2023	2023	97	/images/2024-10-Untitled-2-2.jpg	I just want to express my heartfelt thanks to Nanaska for their incredible CIMA case study program. The support I received—from expert lecturers to personalized guidance and their amazing exam practice tools—made all the difference in my success. Nanaska goes beyond just helping you pass; they build you into a confident, capable leader. Thanks to their program, I passed my case study exam with confidence, and I know I'm better prepared for the future. Thank you for all the support and extra efforts given to pass the exam.	\N	\N	f	t	30	2026-03-20 08:10:53.159	2026-03-29 03:13:08.328
897e5b5b-0b9b-45d5-bc6a-d3647227d5a1	Tharanga Dasanayake	Sri Lanka	🇱🇰	OCS	Operational Case Study	May 2023	2023	\N	/images/2024-10-438952929_457554139982440_4300828445761488087_n-copy.jpg	NANASKA made me feel in safe hands in my CIMA journey with their wonderful ways of teaching. They are a true specialist in CIMA case study exams. Even as a busy manager in a private sector company who has no Finance background, I was really successful in getting through my OCS exam quite comfortably. I would like to thank NANASKA team for their wonderful support in my success.	\N	\N	f	t	32	2026-03-20 08:10:53.175	2026-03-29 03:13:08.335
96115b77-f233-4f75-9821-75beb0c2912c	Nethra Fernando	Sri Lanka	🇱🇰	MCS	Management Case Study (CSEP Pathway)	Feb 2021	2021	\N	/images/2021-06-nethra.jpg	Nanaska's focused approach on improving individuals has worked for me. Not only did Nanaska provide a unique educational service leveraging digitalization, they were right there for me encouraging and mentoring in difficult times. With their holistic approach in preparing for CIMA Case Study, you simply can't go wrong. Thank you, Channa, Wathsala and the Team. Wishing Nanaska for much greater endeavors.	\N	\N	f	t	33	2026-03-20 08:10:53.184	2026-03-29 03:13:08.34
a28478fe-6cbd-4bae-b478-a61ff43b2ddf	Senthil Nathan	Thailand	🇹🇭	SCS	Strategic Case Study	Feb 2021	2021	\N	/images/2021-06-Senthil.jpg	I would like to convey my sincere thanks and appreciation for all the supports that you have provided for my CIMA SCS exam, with all your great support I have cleared my exam in the first attempt. Even though I enrolled with CIMA April-2020 I haven't sat for my exam until Feb-2021, due to my work load. Mr. Channa's way of teaching and the mock exam feedback provided by Ishara and Wathsala was very useful and encouraged me to focus on my studies to improve and get ready for the real exam.	\N	\N	f	t	34	2026-03-20 08:10:53.192	2026-03-29 03:13:08.344
b1c96523-d7b9-49c4-918e-9189fb93defc	Ishara Sandamali Gamage	Sri Lanka	🇱🇰	OCS	Operational Case Study	Feb 2021	2021	\N	/images/2021-06-Ishara.jpg	After completing my Master's degree I joined Nanaska Institute for OCS classes as the very first step of my CIMA journey. It was an amazing experience for me to see how the lecturers of Nanaska helped the students to go through the exams successfully by adhering to various online platforms like online classes, mock exams and via Nanaska website enriched with high quality study materials. I shall be very much thankful to the lecturers of Nanaska Institute, especially to Mr. Channa Gunawardana & Mr. Mark Gunathilaka for their painstaking effort to improve the knowledge & for the motivation extended throughout.	\N	\N	f	t	35	2026-03-20 08:10:53.199	2026-03-29 03:13:08.349
9b8b31d0-240e-42d6-9103-3186ddc1987b	Asela Emilius Theverapperuma	Sri Lanka	🇱🇰	MCS	Management Case Study (CSEP Pathway)	Feb 2021	2021	\N	/images/2021-06-Asela-photo2.jpg	Studying through an online platform was a first time experience for me. NANASKA's teaching methodology and the resources they provide to get me thinking in the right direction were the key attributes that contributed to my success. Coming into the CIMA program from the C-SEP route I had to learn the basics as well whilst preparing for the Case Study. Channa's TEAM managed to make this a simpler task than I expected. Some of the facilities that I found interesting and value adding were the personal attention, any time any place video availability, and the online mocks.	\N	\N	f	t	36	2026-03-20 08:10:53.205	2026-03-29 03:13:08.353
729f2d25-29b0-49a5-ade1-b2a11a923490	Kirit Kumar	Malaysia	🇲🇾	SCS	Strategic Case Study	Feb 2021	2021	\N	/images/2021-06-Kirith-Rumar.jpg	It was indeed a great pleasure being introduced to Nanaska by CIMA. Being a person who have left studies for decades & only 6 weeks given to prepare for the final exam is very challenging. I took every lesson given by Mr. Channa very seriously & revised all the notes provided regularly. The mock papers are important tools for me to get prepared for the final exam. Nanaska has played a major role in turning a person like me from no one to someone today & this exam was my very first & I have managed to pass in first sitting. Nanaska has made great sacrifices in conducting long hour classes and this actually turned their sacrifice into fruitful as I managed to clear at first sitting.	\N	\N	f	t	38	2026-03-20 08:10:53.219	2026-03-29 03:13:08.361
5e214d4b-684a-42b7-a09b-8d62864a22b4	Ramaly Rahuman	Sri Lanka	🇱🇰	MCS	Management Case Study	Feb 2021	2021	\N	/images/2021-06-Ramaly.jpg	Attempting case study was a daunting task for me. Nanaska did everything. The best part was that I could completely trust their team. The course covered a lot of information, delivered in concise chunks that were easy to absorb. The structure was clear, logical and effective. The deep dive, Power mocks, Financial mocks, Refresh theories played a vital role. The main benefits came from doing plenty of mock papers and receiving individual feedback. I am looking forward to working with Mr. Channa and Nanaska for Strategy level exams and I strongly recommend Nanaska for other students as well.	\N	\N	f	t	39	2026-03-20 08:10:53.225	2026-03-29 03:13:08.366
11adae2f-9dab-4d28-ab5b-bace91286a07	Luong Thi Thuy Linh	Malaysia	🇲🇾	SCS	Strategic Case Study	Nov 2020	2020	\N	/images/2021-06-Luong-Thi-Thuy-Linh-Malaysia.jpg	I am very grateful for what Nanaska had prepared for my Strategic Case Study exam. Thank you, Mr. Channa and Nanaska team for the inspiring lectures, the comprehensive and unique learning materials as well as the one to one coaching sections after each mock exam.	\N	Country Prize Winner	t	t	41	2026-03-20 08:10:53.239	2026-03-29 03:13:08.378
381ee053-7698-44f7-b284-028a702e0d51	Naveed Anjoon	Sri Lanka	🇱🇰	MCS	Management Case Study (CSEP Pathway)	Nov 2020	2020	\N	/images/2021-06-Naveed.jpeg	As a Senior Sales and Marketing professional and someone who didn't do any exams in the last 5 years, I had my own doubts whether I'll be able to pass the exams in one go. I consider myself lucky to have joined Nanaska as it gave me the full confidence within the first couple of weeks itself that it is possible to pass the exams provided we put in the hard work. And I DID GET THROUGH! The structure used, ground rules, deep dives, mock papers provided, theory revision and the 1-2-1 feedback sessions were phenomenal. I have no hesitation in recommending Nanaska for CIMA education.	\N	\N	f	t	42	2026-03-20 08:10:53.244	2026-03-29 03:13:08.382
aeb784a3-c199-49d8-b904-ebf773bebb60	Nason Zhang	Sri Lanka	🇱🇰	MCS	Management Case Study (CSEP Pathway)	Nov 2020	2020	\N	/images/2021-06-Nason-Zhang-CICT.jpg	It's a great and fruitful journey with Nanaska Team in pursuing the achievement of CIMA. Mr. Channa's class is an excellent combination of theoretical knowledge and modern practice. The work experience shared, the industrial leader seminar held, abundant network resources, the individual study guidance group — with quite a lot encouragement and supervision — would be the most advantageous tools not only in passing CIMA exam, but also in improving your Financial Profession.	\N	\N	f	t	43	2026-03-20 08:10:53.248	2026-03-29 03:13:08.387
8635d77b-8837-4286-a226-05bcf683f69f	Hasini Erangika	Sri Lanka	🇱🇰	MCS	Management Case Study	Aug 2020	2020	\N	/images/2021-06-p2.png	Mr. Channa from NANASKA led me on my CIMA journey. NANASKA prepared me for the CIMA SCS exam by providing me with the requisite subject information, study notes, time management skills, and exam strategy to pass the CIMA SCS exam with flying colours. Mr. Channa's online classes and notes, which included KYP, KYI, refresh theory, Deep Dive, podcasts, and mock exams, laid a strong foundation for taking the exam. Nanaska comes highly recommended by me.	\N	\N	f	t	44	2026-03-20 08:10:53.253	2026-03-29 03:13:08.391
7492c8fe-2c70-42c1-befd-dc111aa5e12e	Nilhan Perera	Sri Lanka	🇱🇰	MCS	Management Case Study	Aug 2020	2020	\N	/images/2021-06-42059622_10217225943069133_3879775985771479040_n.jpg	I started my CIMA journey through the Management Case study from the Gateway route. Channa and the team immensely helped me as I had to cover all three theory areas since I didn't do the OTQs, but Nanaska has a superlative forum which gave access to me and that had every tool that I needed to get through the exam. Personal one to one session was a big turning point in motivating me and it also gave me a clear opportunity to clear my doubts. Team Nanaska has a true passion and commitment to what they do so I would highly recommend Nanaska to any prospective student looking to study CIMA.	\N	\N	f	t	45	2026-03-20 08:10:53.259	2026-03-29 03:13:08.396
3a5bda65-9f06-4894-8ec4-879a7cdbf614	Jimson George	Oman	🇴🇲	SCS	Strategic Case Study	Aug 2020	2020	\N	/images/2021-06-WhatsApp-Image-2021-04-18-at-8.35.12-PM.jpg	With Nanaska I could pass the Management Level Case study exam in my first attempt. They have planned everything in advance in order to support us to get through this. Also they have a team who are very supportive and they have directly advised me regarding the areas to improve at one to one session. I am really thankful to Channa sir and the Nanaska team who supported me throughout this journey and wish they could guide many more students toward success.	\N	\N	f	t	46	2026-03-20 08:10:53.267	2026-03-29 03:13:08.4
87f939ee-1e4d-4f54-8e3e-33cccb28d478	Godwin Gyimah	Ghana	🇬🇭	MCS	Management Case Study	Aug 2020	2020	\N	/images/2021-06-attachment1.jpg	I had a very great experience with Nanaska and that helped me pass my gateway exams. Firstly, I had not studied accounting before I joined CIMA — I have an engineering degree, MBA, and work as an HR professional. With the help of Nanaska's learning approach and how they prepared me for the exams, I passed on my first attempt. Nanaska webinars and mocks were very helpful to give you a feel of how the exam day looks like and made me relaxed during the exams. The team was also helpful in providing relevant information regularly in a different form which allowed for different approaches to learning.	\N	\N	f	t	47	2026-03-20 08:10:53.276	2026-03-29 03:13:08.403
fd411d59-96a3-4aac-9e6a-1c1747d4f006	Vinesh Moodley	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2020	2020	\N	/images/2021-06-Vinesh-Moodley-1-_-United-Arab-Emirates-1.jpg	I successfully passed both the MCS and SCS exams during 2020 with Nanaska as my tuition provider. Studying remotely and online especially during 2020 was really challenging but partnering with a tuition provider like Nanaska allowed me to fulfil my increased work commitments as well as keep up to date with my studies. Channa's practical experience and his ability to combine this with the theory required is top class and a crucial aspect to success in the CIMA exams. His dedication and passion for the subject matter is truly inspiring and certainly helped me to be successful. I have no hesitation in recommending Nanaska as a preferred CIMA tuition provider.	\N	\N	f	t	48	2026-03-20 08:10:53.282	2026-03-29 03:13:08.407
9f422637-4eec-418a-a8f6-3a0fc0376296	Narmatha Murali	UK	🇬🇧	SCS	Strategic Case Study	May 2017	2017	102	/images/2021-06-Narmatha.png	I enrolled in Nanaska's online programme to help with my SCS exam which I failed to get through in my previous two attempts. The support and guidance from the lecturer has helped me to pass this paper with 102 scores. Setting aside time to study for a professional exam had been a challenge for me. Nanaska's programme provided the flexibility to juggle around my work, family and studies. The weekly follow up sessions are really motivational in terms of keeping you ahead of the game and broaden your thinking. The feed back for mock papers are very useful in identifying the areas where you need improvement. The level of support and motivation given to students by Nanaska team is truly amazing!!	\N	\N	f	t	49	2026-03-20 08:10:53.288	2026-03-29 03:13:08.411
af0f004c-01a0-4bc9-bd50-54d3f27ee652	Chenuka Pasindu	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	98	/images/2024-10-Chenuka-MCS-copy.jpg	I am thrilled to share that I recently passed the CIMA Management Case Study exam with 98 marks, and I owe a great deal of my success to Nanaska. After a five-year break from CIMA, I felt out of touch with the subject matter. However, the incredible support and guidance from Nanaska, particularly Channa Sir, made all the difference. Channa Sir's lecturing skills are exceptional. Even though the classes were online, they felt just like being in a physical classroom. His engaging teaching style, clear explanations, and practical insights helped me grasp complex concepts with ease. The mock exams and the detailed feedback I received were invaluable. They not only highlighted my strengths and weaknesses but also provided me with a clear roadmap to improve. The constructive criticism and encouragement from the Nanaska staff, including Channa Sir, played a crucial role in my preparation. Nanaska's comprehensive approach and dedicated team helped me navigate through the CIMA syllabus efficiently, boosting my confidence and knowledge. I am grateful for their unwavering support and highly recommend their services to anyone pursuing CIMA.	\N	\N	f	t	5	2026-03-20 08:10:52.991	2026-03-29 03:13:08.197
8af5bc10-c3ad-4276-b0eb-2b74013a33ba	Aheshma Perera	Sri Lanka	🇱🇰	OCS	Operational Case Study	Feb 2024	2024	87	/images/2024-10-ashenma.jpg	The reason I chose Nanaska as my tuition provider for the OCS was that the academic staff of Nanaska follow up and keep in touch with the students throughout the whole period, while encouraging us to finish every mock on time and by providing us tailor made guidance to improve our writing skills, techniques, speed and thinking pattern through productive methods such as one to one sessions and mock answers that are marked very detailed highlighting student weaknesses.	\N	\N	f	t	20	2026-03-20 08:10:53.09	2026-03-29 03:13:08.226
8b88c4c8-2963-4d2b-886c-3848e30f8489	Umasha Malgalla	Sri Lanka	🇱🇰	MCS	Management Case Study	May 2024	2024	83	/images/2024-10-Umasha-MCS-copy.jpg	Thanks to the guidance of Channa sir and the support of the Nanaska team, I have successfully passed my MSC case study. The lectures, strategies, and mock exams they provided were invaluable in preparing me for this examination. Additionally, the one-on-one discussions and detailed feedback on marked mocks were helpful in clarifying all my doubts and to enhance my confidence to face the exam well. I am deeply grateful for their unwavering support and dedication. Therefore, I highly recommend Channa sir and the services of the Nanaska team to any student striving for success in CIMA exams.	\N	\N	f	t	10	2026-03-20 08:10:53.027	2026-03-29 03:13:08.231
4ff39666-25b9-45db-b0ef-feee7b328225	Daminda Bandara	Sri Lanka	🇱🇰	OCS	Operational Case Study	Feb 2024	2024	90	/images/2024-10-Daminda-1.jpg	CIMA was a Start for Turning point in My Life — even having obtained few Professional and Academic qualifications, it was a very Hard Time to face this challenge while doing the Job. But during such time Nanaska became my second home. Lectures with their expanded knowledge and Academic Staff were Always behind us in technical and administrative supports. Mr. Osman Fernando always behind us as a Motivator and Guider, due to this personal attention by a Lecturer for Student was highly supported to overcome theoretical problems, its application and release work life stress situations quickly. The secret is the entire Nanaska Team.	\N	\N	f	t	19	2026-03-20 08:10:53.085	2026-03-29 03:13:08.28
a2156972-b4ed-4a84-9bb7-2ea2a0a63b63	Eugene Akorli	Ghana	🇬🇭	OCS	Operational Case Study	May 2023	2023	93	/images/2024-10-Untitled-2-3.jpg	Leading up to the OCS exam I had struggled with P1 (management accounting), failing once and postponing a couple of times before eventually passing. And so when I learnt the OCS will be heavily based on P1 theory I was really nervous but a friend recommended Nanaska and I decided to put my trust in them and it paid off! The teaching methods used by Nanaska helped me to believe that if I put in the required effort I could achieve the result I wanted. All I had to do was follow their lessons, complete the tasks we were assigned and I saw myself growing in confidence. The responsiveness and dedication of the team at Nanaska proved really valuable and made me feel that I had all the support I needed to pass the exam. I'm very grateful to the team and I look forward to benefiting from their tutelage again in future exams.	\N	Prize Winner	t	t	31	2026-03-20 08:10:53.167	2026-03-29 03:13:08.331
2f44c06b-ab1c-4ab8-8b75-2e4f5267e6a9	Ranjitkumar Thivakaran	Australia	🇦🇺	SCS	Strategic Case Study	Feb 2021	2021	\N	/images/2021-06-Thivakaran-scaled.jpg	Coming together is a beginning, Keeping together is progress, Working together is success — Henry Ford. I resumed my strategic level case study exam from old syllabus to new syllabus. I got to know that Channa is doing classes online then I was enrolled for the session. From the start of the session, the objective was clear that Nanaska team want all of us to see success in the exam. Industry knowledge and theoretical explanation are the core of the session. As the progress goes on mock papers played a key role to understand the exam condition and also to understand our mistakes in writing an answer. I highly recommend students who are seeking for their success in CIMA exams to be associated with Nanaska institution.	\N	\N	f	t	37	2026-03-20 08:10:53.212	2026-03-29 03:13:08.357
41cc0565-82e7-4af6-90d4-7c91d92ccc74	Adegbite Adekola	Nigeria	🇳🇬	SCS	Strategic Case Study	May 2017	2017	\N	/images/2021-06-p2.png	I took the SCS with a different tutor last year. He spent only one weekend to go over the material; the rest was left to me to figure out. That partnership failed. This year, I went for Nanaska. From the get-go, I knew they were different: website, personal profiles, proper admin, podcasts, etc. Then it came time to deep dive; we met regularly, lots of reading material, and WhatsApp forum. We had webinars every weekend to go over new information and questions from the week. We then progressed to the practice mocks with one-on-one feedback. Success was resounding.	\N	\N	f	t	52	2026-03-20 08:10:53.308	2026-03-29 03:13:08.422
c2adbdca-5b88-4c0e-8138-266c2a30960d	Tin Mar Yi	Myanmar	🇲🇲	SCS	Strategic Case Study	May 2017	2017	\N	/images/2021-06-Tin.png	Before I knew about Nanaska and Mr. Channa, I was the person who does not have the enough level of confidence to pass the CIMA SCS exam. With the support of Channa Sir and Nanaska team, through the mock exams, I knew about my strengths and weaknesses of my knowledge and experience to face the real exam. When I sat the real exam, I noticed that I could manage the time and answering points that pushed me to pass the exam. With Nanaska and Channa Sir's support, I could pass the exam. I strongly believe that Nanaska has the best method to pass the SCS exam.	\N	\N	f	t	53	2026-03-20 08:10:53.316	2026-03-29 03:13:08.426
55959ae2-4f30-4583-a649-4f15bd5af631	Antony Nimesh Jayawardena	UAE	🇦🇪	SCS	Strategic Case Study	Nov 2020	2020	\N	/images/2021-06-Nimesh.jpg	I joined CIMA through the CIMA Gateway programme. Thanks to Mr. Channa and Nanaska, revision sessions were organized which gave me an excellent overall view and knowledge on the theory subjects. From the beginning of the SCS case study Mr. Channa trained us to think practically which was the essence for my success in SCS case study. The programme was well structured which contained more than 5 mock exams, summarizing of the case study, Possible questions and an overall view of the industry. Nanaska even went up to the extent of having sessions by experts in the related industry. I highly recommend Nanaska to prospective students who are eager to achieve success in the Corporate world.	\N	Joint Country Prize Winner	t	t	40	2026-03-20 08:10:53.232	2026-03-29 03:13:08.372
3b456e93-f43a-4757-84a3-969755113681	Patricia Duru	Nigeria	🇳🇬	SCS	Strategic Case Study	May 2017	2017	\N	/images/2021-06-Patricia.jpg	Thank you Nanaska (LearnCIMA) for making my first attempt at Strategic Case Study a successful one. The training methodology is undeniably unique and very effective considering the tight work schedule of most students. The podcasts, weekly live discussion sessions with Channa, WhatsApp group chats, mocks written in simulated CIMA exam portal, one-on-one sessions for review of mocks, access to a rich study library etc. are viable tools that facilitate success of students at the CIMA exams. Well done team Nanaska!	\N	\N	f	t	51	2026-03-20 08:10:53.303	2026-03-29 03:13:08.418
\.


--
-- Data for Name: user_courses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_courses (id, user_id, course_id, order_id, granted_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, name, created_at) FROM stdin;
\.


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: contact_submissions contact_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_submissions
    ADD CONSTRAINT contact_submissions_pkey PRIMARY KEY (id);


--
-- Name: course_combination_items course_combination_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course_combination_items
    ADD CONSTRAINT course_combination_items_pkey PRIMARY KEY (id);


--
-- Name: course_combinations course_combinations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course_combinations
    ADD CONSTRAINT course_combinations_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: enrollment_reminders enrollment_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_reminders
    ADD CONSTRAINT enrollment_reminders_pkey PRIMARY KEY (id);


--
-- Name: enrollment_submissions enrollment_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_submissions
    ADD CONSTRAINT enrollment_submissions_pkey PRIMARY KEY (id);


--
-- Name: lecturers lecturers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lecturers
    ADD CONSTRAINT lecturers_pkey PRIMARY KEY (id);


--
-- Name: newsletter_signups newsletter_signups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_signups
    ADD CONSTRAINT newsletter_signups_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: page_meta page_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_meta
    ADD CONSTRAINT page_meta_pkey PRIMARY KEY (id);


--
-- Name: payment_links payment_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_links
    ADD CONSTRAINT payment_links_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: user_courses user_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT user_courses_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: admin_users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX admin_users_email_key ON public.admin_users USING btree (email);


--
-- Name: blog_posts_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_posts_slug_key ON public.blog_posts USING btree (slug);


--
-- Name: course_combination_items_combination_id_course_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX course_combination_items_combination_id_course_id_key ON public.course_combination_items USING btree (combination_id, course_id);


--
-- Name: course_combinations_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX course_combinations_slug_key ON public.course_combinations USING btree (slug);


--
-- Name: courses_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX courses_slug_key ON public.courses USING btree (slug);


--
-- Name: enrollment_reminders_enrollment_id_reminder_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX enrollment_reminders_enrollment_id_reminder_number_key ON public.enrollment_reminders USING btree (enrollment_id, reminder_number);


--
-- Name: newsletter_signups_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX newsletter_signups_email_key ON public.newsletter_signups USING btree (email);


--
-- Name: page_meta_page_path_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX page_meta_page_path_key ON public.page_meta USING btree (page_path);


--
-- Name: payment_links_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payment_links_slug_key ON public.payment_links USING btree (slug);


--
-- Name: site_settings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX site_settings_key_key ON public.site_settings USING btree (key);


--
-- Name: user_courses_user_id_course_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_courses_user_id_course_id_key ON public.user_courses USING btree (user_id, course_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: course_combination_items course_combination_items_combination_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course_combination_items
    ADD CONSTRAINT course_combination_items_combination_id_fkey FOREIGN KEY (combination_id) REFERENCES public.course_combinations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: course_combination_items course_combination_items_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course_combination_items
    ADD CONSTRAINT course_combination_items_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: enrollment_reminders enrollment_reminders_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollment_reminders
    ADD CONSTRAINT enrollment_reminders_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollment_submissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_combination_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_combination_id_fkey FOREIGN KEY (combination_id) REFERENCES public.course_combinations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_payment_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_payment_link_id_fkey FOREIGN KEY (payment_link_id) REFERENCES public.payment_links(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_courses user_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT user_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_courses user_courses_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT user_courses_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_courses user_courses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT user_courses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict nCzFTSwLltur4Wr4dX1bfcRnpmgVGmpyWYJ1wtgjl3Gu4HQaTmAiRDlHNjyyka5

